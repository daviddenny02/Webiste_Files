// David Denny Embedded Project README

These are the most relevant files for the System Calls assignment.
A full copy of the project directory can be found on my GitHub page.
Here are what the following files achieve in this project:

pstat.h -- This header file adds a couple attributes that are given
		to a process. These attributes are altered with the
		other implemented system calls.

proc.c -- This file defines the functionality of the added system
		calls at the kernel level. These are in addition to
		the predefined xv6 system calls. The added calls are
		setColor(), setTickets(), and gpinfo().

ps.c -- This file is created in the user-space of the operating system,
		and is a test file simulating their usage by a user.
		The test file calls each of the added system calls and
		ensures they operate correctly.