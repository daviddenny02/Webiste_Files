// David Denny, 1001915603
// Trevor Bakker
// Assignment 3

#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

enum procstate { UNUSED, USED, SLEEPING, RUNNABLE, RUNNING, ZOMBIE };
enum COLOR { RED, ORANGE, YELLOW, GREEN, BLUE, INDIGO, VIOLET };

#include "kernel/pstat.h"

// My implementation of setColor() passes in an int to
// represent a color. The key for this is below:

// 0 = RED
// 1 = ORANGE
// 2 = YELLOW
// 3 = GREEN
// 4 = BLUE
// 5 = INDIGO
// 6 = VIOLET

int main(int argc, char* argv[]){

    // Used for getpinfo
    struct pstat table;
    struct pstat* tablePtr = &table;

    // Here are sample system calls for my implementation
    // of setColor() and setTickets():

    // enum COLOR testColor = BLUE;
    // setColor(testColor);
    // setTickets(9);

    // Call getpinfo()
    // Pass in struct to be filled by the system call,
    // which is printed below:
    getpinfo(tablePtr);

    printf("NAME\tPID\tSTATUS\t\tCOLOR\tTICKETS\n");

    int i;
    for(i = 0; i < NPROC; i++){
    
        if(tablePtr->inuse[i] == 0){
            continue;
        } // Continue if unused processes is found

        printf("%s\t", tablePtr->name[i]);
        printf("%d\t", tablePtr->pid[i]);

        // Printing status of the processes
        if(tablePtr->state[i] == 0){printf("UNUSED\t\t");}
        else if(tablePtr->state[i] == 1){printf("USED\t\t");}
        else if(tablePtr->state[i] == 2){printf("SLEEPING\t");}
        else if(tablePtr->state[i] == 3){printf("RUNNABLE\t");}
        else if(tablePtr->state[i] == 4){printf("RUNNING\t\t");}
        else if(tablePtr->state[i] == 5){printf("ZOMBIE\t\t");}

        // Printing the colors of the processes
        if(tablePtr->color[i] == 0){printf("RED\t");}
        else if(tablePtr->color[i] == 1){printf("ORANGE\t");}
        else if(tablePtr->color[i] == 2){printf("YELLOW\t");}
        else if(tablePtr->color[i] == 3){printf("GREEN\t");}
        else if(tablePtr->color[i] == 4){printf("BLUE\t");}
        else if(tablePtr->color[i] == 5){printf("INDIGO\t");}
        else if(tablePtr->color[i] == 6){printf("VIOLET\t");}

        // Printing the tickets held by each process
        printf("%d\n", tablePtr->tickets[i]);
    }

    return 0;
}