// David Denny, 1001915603
// RTOS Project
// RTOS Tasks

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdint.h>
#include <stdbool.h>
#include "tm4c123gh6pm.h"
#include "wait.h"
#include "kernel.h"
#include "tasks.h"
#include "uart0.h"
#include "asm.h"

// Mini-Project Register Masks and Bitband Aliases
#define RED_LED             (*((volatile uint32_t *)(0x42000000 + (0x400243FC-0x40000000)*32 + 0*4))) // Port E0
#define ORANGE_LED          (*((volatile uint32_t *)(0x42000000 + (0x400043FC-0x40000000)*32 + 2*4))) // Port A2
#define YELLOW_LED          (*((volatile uint32_t *)(0x42000000 + (0x400043FC-0x40000000)*32 + 3*4))) // Port A3
#define GREEN_LED           (*((volatile uint32_t *)(0x42000000 + (0x400043FC-0x40000000)*32 + 4*4))) // Port A4

// Port Masks
#define BLUE_LED_MASK 4
#define RED_LED_MASK 1
#define ORANGE_LED_MASK 4
#define YELLOW_LED_MASK 8
#define GREEN_LED_MASK 16

#define PUSH_BUTTON_ONE_MASK   1
#define PUSH_BUTTON_TWO_MASK   2
#define PUSH_BUTTON_THREE_MASK 4
#define PUSH_BUTTON_FOUR_MASK  8
#define PUSH_BUTTON_FIVE_MASK  2
#define PUSH_BUTTON_SIX_MASK   4

#define PB1_LOG_MASK   1
#define PB2_LOG_MASK   2
#define PB3_LOG_MASK   4
#define PB4_LOG_MASK   8
#define PB5_LOG_MASK   16
#define PB6_LOG_MASK   32

#define PUSH_BUTTON_ONE     (*((volatile uint32_t *)(0x42000000 + (0x400073FC-0x40000000)*32 + 0*4))) // Port D0
#define PUSH_BUTTON_TWO     (*((volatile uint32_t *)(0x42000000 + (0x400073FC-0x40000000)*32 + 1*4))) // Port D1
#define PUSH_BUTTON_THREE   (*((volatile uint32_t *)(0x42000000 + (0x400073FC-0x40000000)*32 + 2*4))) // Port D2
#define PUSH_BUTTON_FOUR    (*((volatile uint32_t *)(0x42000000 + (0x400073FC-0x40000000)*32 + 3*4))) // Port D3
#define PUSH_BUTTON_FIVE    (*((volatile uint32_t *)(0x42000000 + (0x400243FC-0x40000000)*32 + 1*4))) // Port E1
#define PUSH_BUTTON_SIX     (*((volatile uint32_t *)(0x42000000 + (0x400243FC-0x40000000)*32 + 2*4))) // Port E2

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

// Initialize Hardware
// REQUIRED: Add initialization for blue, orange, red, green, and yellow LEDs
//           Add initialization for 6 pushbuttons
void initHw(void)
{
    // Setup LEDs and pushbuttons
    // Initialize system clock to 40 MHz
    // Configure HW to work with 16 MHz XTAL, PLL enabled, sysdivider of 5, creating system clock of 40 MHz
    SYSCTL_RCC_R = SYSCTL_RCC_XTAL_16MHZ | SYSCTL_RCC_OSCSRC_MAIN | SYSCTL_RCC_USESYSDIV | (4 << SYSCTL_RCC_SYSDIV_S);

    // Enable clocks
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R0 | SYSCTL_RCGCGPIO_R3 | SYSCTL_RCGCGPIO_R4 | SYSCTL_RCGCGPIO_R5;
    _delay_cycles(3);

    // Configure LED and pushbutton pins
    GPIO_PORTF_DIR_R |= BLUE_LED_MASK;
    GPIO_PORTF_DEN_R |= BLUE_LED_MASK;
    GPIO_PORTE_DIR_R |= RED_LED_MASK;
    GPIO_PORTE_DEN_R |= RED_LED_MASK;
    GPIO_PORTA_DIR_R |= ORANGE_LED_MASK | YELLOW_LED_MASK | GREEN_LED_MASK;
    GPIO_PORTA_DEN_R |= ORANGE_LED_MASK | YELLOW_LED_MASK | GREEN_LED_MASK;

    GPIO_PORTD_DEN_R |= PUSH_BUTTON_ONE_MASK | PUSH_BUTTON_TWO_MASK | PUSH_BUTTON_THREE_MASK | PUSH_BUTTON_FOUR_MASK;
    GPIO_PORTD_DIR_R &= ~PUSH_BUTTON_ONE_MASK;
    GPIO_PORTD_DIR_R &= ~PUSH_BUTTON_TWO_MASK;
    GPIO_PORTD_DIR_R &= ~PUSH_BUTTON_THREE_MASK;
    GPIO_PORTD_DIR_R &= ~PUSH_BUTTON_FOUR_MASK;

    GPIO_PORTE_DEN_R |= PUSH_BUTTON_FIVE_MASK | PUSH_BUTTON_SIX_MASK;
    GPIO_PORTE_DIR_R &= ~PUSH_BUTTON_FIVE_MASK;
    GPIO_PORTE_DIR_R &= ~PUSH_BUTTON_SIX_MASK;

    // Declare all PBs as Pull-Up Resistors
    GPIO_PORTD_PUR_R |= PUSH_BUTTON_ONE_MASK | PUSH_BUTTON_TWO_MASK | PUSH_BUTTON_THREE_MASK | PUSH_BUTTON_FOUR_MASK;
    GPIO_PORTE_PUR_R |= PUSH_BUTTON_FIVE_MASK | PUSH_BUTTON_SIX_MASK;

    // Turn off all LEDs
    GPIO_PORTF_DATA_R &= ~BLUE_LED_MASK;
    RED_LED = 0;
    ORANGE_LED = 0;
    YELLOW_LED = 0;
    GREEN_LED = 0;

    // Turn on other faults
    NVIC_SYS_HND_CTRL_R |= (1 << 16) | (1 << 17) | (1 << 18); // Enable Memory, Bus, Usage Faults
    NVIC_CFG_CTRL_R |= (1 << 4) | (1 << 3); // Enable DIV0 and unaligned access Usage Faults

    // Initialize sysTick HW
    NVIC_ST_RELOAD_R = 40000 - 1U;
    NVIC_ST_CURRENT_R = 0;
    NVIC_ST_CTRL_R = NVIC_ST_CTRL_ENABLE | NVIC_ST_CTRL_INTEN | NVIC_ST_CTRL_CLK_SRC;

    // Power-up flash
    GREEN_LED = 1;
    waitMicrosecond(250000);
    GREEN_LED = 0;
    waitMicrosecond(250000);
}

// REQUIRED: add code to return a value from 0-63 indicating which of 6 PBs are pressed
uint8_t readPbs(void)
{
    uint8_t mask = 0;

    if (!PUSH_BUTTON_ONE)   mask |= PB1_LOG_MASK;
    if (!PUSH_BUTTON_TWO)   mask |= PB2_LOG_MASK;
    if (!PUSH_BUTTON_THREE) mask |= PB3_LOG_MASK;
    if (!PUSH_BUTTON_FOUR)  mask |= PB4_LOG_MASK;
    if (!PUSH_BUTTON_FIVE)  mask |= PB5_LOG_MASK;
    if (!PUSH_BUTTON_SIX)   mask |= PB6_LOG_MASK;

    return mask;
}

// one task must be ready at all times or the scheduler will fail
// the idle task is implemented for this purpose
void idle(void)
{
    putsUart0("Idle() started...\n");
    while(true)
    {
        ORANGE_LED = 1;
        waitMicrosecond(1000);
        ORANGE_LED = 0;
        yield();
    }
}

void flash4Hz(void)
{
    putsUart0("Flash4Hz() started...\n");
    while(true)
    {
        GREEN_LED = !GREEN_LED;
        sleep(125);
    }
}

void oneshot(void)
{
    putsUart0("Oneshot() started...\n");
    while(true)
    {
        wait(flashReq);
        YELLOW_LED = 1;
        sleep(1000);
        YELLOW_LED = 0;
    }
}

void partOfLengthyFn(void)
{
    // represent some lengthy operation
    waitMicrosecond(990);
    // give another process a chance to run
    yield();
}

void lengthyFn(void)
{
    putsUart0("LengthyFn() started...\n");
    uint16_t i;
    while(true)
    {
        lock(resource);
        for (i = 0; i < 5000; i++)
        {
            partOfLengthyFn();
        }
        RED_LED = !RED_LED;
        unlock(resource);
    }
}

void readKeys(void)
{
    putsUart0("ReadKeys() started...\n");
    uint8_t buttons;
    while(true)
    {
        wait(keyReleased);
        buttons = 0;
        while (buttons == 0)
        {
            buttons = readPbs();
            yield();
        }
        post(keyPressed);
        if ((buttons & 1) != 0)
        {
            putsUart0("PB1 Pressed\n");
            YELLOW_LED = !YELLOW_LED;
            RED_LED = 1;
        }
        if ((buttons & 2) != 0)
        {
            putsUart0("PB2 Pressed\n");
            post(flashReq);
            RED_LED = 0;
        }
        if ((buttons & 4) != 0)
        {
            putsUart0("PB3 Pressed\n");
            restartThread(flash4Hz);
        }
        if ((buttons & 8) != 0)
        {
            putsUart0("PB4 Pressed\n");
            stopThread(flash4Hz);
        }
        if ((buttons & 16) != 0)
        {
            putsUart0("PB5 Pressed\n");
            setThreadPriority(lengthyFn, 4);
        }
        yield();
    }
}

void debounce(void)
{
    putsUart0("Debounce() started...\n");
    uint8_t count;
    while(true)
    {
        wait(keyPressed);
        count = 10;
        while (count != 0)
        {
            sleep(10);
            if (readPbs() == 0)
                count--;
            else
                count = 10;
        }
        post(keyReleased);
    }
}

void uncooperative(void)
{
    putsUart0("Uncooperative() started...\n");
    while(true)
    {
        while (readPbs() == 8)
        {
        }
        yield();
    }
}

void errant(void)
{
    putsUart0("Errant() started...\n");
    uint32_t* p = (uint32_t*)0x20000000;
    while(true)
    {
        while (readPbs() == 32)
        {
            *p = 0;
        }
        yield();
    }
}

void important(void)
{
    putsUart0("Important() started...\n");
    while(true)
    {
        lock(resource);
        GPIO_PORTF_DATA_R |= BLUE_LED_MASK; // Turn on LED
        sleep(1000); // base 1000
        GPIO_PORTF_DATA_R &= ~BLUE_LED_MASK; // Turn off LED
        unlock(resource);
    }
}
