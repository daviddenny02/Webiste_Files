// David Denny, 1001915603
// RTOS Project
// Memory Management

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

#ifndef MM_H_
#define MM_H_

#define NUM_SRAM_REGIONS 8

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

void initBackgroundRule(void);
void enableMpu(void);
void disableMpu(void);
void allowFlashAccess(void);
void allowPeripheralAccess(void);
void allowSramAccess(void);
void applySramAccessMask(uint64_t srdBitMask);
uint64_t createNoSramAccessMask(void);
void addSramAccessWindow(uint64_t *srdBitMask, void *baseAdd, uint32_t size_in_bytes);
void printMemTable(void);
void * mallocHeap(uint32_t size_in_bytes);
void freeHeap(void *address_from_malloc);
void initMpu(void);

#endif
