// David Denny, 1001915603
// RTOS Project
// Helper Functions

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL
// Target uC:       TM4C123GH6PM
// System Clock:    40MHz

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#ifndef FUNCTIONS_H_
#define FUNCTIONS_H_

#include <stdint.h>
#include <stdbool.h>

// Max UART command widths
#define MAX_CHARS 80
#define MAX_FIELDS 5

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

void int32_to_hex(uint32_t value, char *str);
void print_hex(uint32_t value);
char* int32_to_string(uint32_t pid);
void FaultDecoder(void);

#endif
