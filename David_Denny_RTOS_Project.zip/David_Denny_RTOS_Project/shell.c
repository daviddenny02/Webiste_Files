// David Denny, 1001915603
// RTOS Project
// Shell Functionality

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include "clock.h"
#include "wait.h"
#include "uart0.h"
#include "functions.h"
#include "tm4c123gh6pm.h"
#include "shell.h"
#include "tasks.h"
#include "kernel.h"
#include "functions.h"
#include "asm.h"

// Max UART command widths
#define MAX_CHARS 80
#define MAX_FIELDS 5

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

// This function gets an input string from user.
void getsUart0(USER_DATA* data)
{
    int count = 0;

    while(true)
    {
        // Yielding if the UART has not received anything
        if (!kbhitUart0())
        {
            yield();
            continue;
        }

        char c = getcUart0();

        if((c == 8) || (c == 127))
        { // is c == backspace?
            if(count > 0)
            { // is count > 0?
                count--;
                continue;
            }
            else
            { // count !> 0
                continue;
            }
        }
        else
        { // c != backspace
            if(c == 13)
            { // is c == return?
                data->buffer[count] = '\0'; // Null terminator and return
                return;
            }
            else
            { // c != return
                if(c >= 32)
                { // is c >= space?
                    data->buffer[count] = c;
                    count++;
                    if(count == MAX_CHARS)
                    { // is the buffer full?
                        data->buffer[count] = 0; // Null terminator and return
                    }
                    else
                    { // the buffer is not full
                        continue;
                    }
                }
                else
                { // c != space
                    continue;
                }
            }
        }
    }
}

// This function parses the field, separating alpha, numerics, and delimiters
void parseFields(USER_DATA* data)
{
    int parser;
    int alphaFlag;
    int numericFlag;

    data->fieldCount = 0;

    for(parser = 0; parser < MAX_CHARS; parser++){

        alphaFlag = 0;
        numericFlag = 0;

        if((data->buffer[parser] == '\0') || (data->fieldCount == MAX_FIELDS)){ // end of the buffer string
            break;
        }
        else if(((data->buffer[parser] >= 65) && (data->buffer[parser] <= 90)) || ((data->buffer[parser] >= 97) && (data->buffer[parser] <= 122))){ // alpha found
            alphaFlag = 1;
        }
        else if((data->buffer[parser] >= 48) && (data->buffer[parser] <= 57)){ // numeric found
            numericFlag = 1;
        }
        else{ // delimiter found
            data->buffer[parser] = NULL;
            continue;
        }

        // Transition from start of string to alpha
        if((alphaFlag == 1) && ((data->fieldCount) == 0)){
            data->fieldPosition[(data->fieldCount)] = parser;
            data->fieldType[(data->fieldCount)] = 'a';
            data->fieldCount = (data->fieldCount) + 1;
            continue;
        }

        // Transition from delimiter to alpha
        else if((alphaFlag == 1) && ((data->buffer[(parser - 1)]) == NULL)){
            data->fieldPosition[(data->fieldCount)] = parser;
            data->fieldType[(data->fieldCount)] = 'a';
            data->fieldCount = (data->fieldCount) + 1;
            continue;
        }

        // Transition from start of string to numeric
        if((numericFlag == 1) && ((data->fieldCount) == 0)){
            data->fieldPosition[(data->fieldCount)] = parser;
            data->fieldType[(data->fieldCount)] = 'n';
            data->fieldCount = (data->fieldCount) + 1;
            continue;
        }

        // Transition from delimiter to numeric
        else if((numericFlag == 1) && ((data->buffer[(parser - 1)]) == NULL)){
            data->fieldPosition[(data->fieldCount)] = parser;
            data->fieldType[(data->fieldCount)] = 'n';
            data->fieldCount = (data->fieldCount) + 1;
            continue;
        }
    }
    return;
}

// This function returns the string in field (fieldNumber + 1)
// So fieldNumber = 2, the string in field 3 is returned
char* getFieldString(USER_DATA* data, uint8_t fieldNumber)
{
    // return 0 if the field is not an alpha, or if it is out of range
    if ((data->fieldType[fieldNumber] != 'a') || (fieldNumber >= data->fieldCount)){
        return 0;
    }
    return &(data->buffer[data->fieldPosition[fieldNumber]]);
}

// This function returns the integer in field (fieldNumber + 1)
// So fieldNumber = 2, the integer in field 3 is returned
int32_t getFieldInteger(USER_DATA* data, uint8_t fieldNumber)
{
    // return 0 if the field is not a number, or if it is out of range
    if ((data->fieldType[fieldNumber] != 'n') || (fieldNumber >= data->fieldCount)){
        return 0;
    }
    return atoi(&(data->buffer[data->fieldPosition[fieldNumber]]));
}

// This function returns true if a command and requisite arguments are passed in.
bool isCommand(USER_DATA* data, const char strCommand[], uint8_t minArguments)
{
    if((data->fieldCount) != (minArguments + 1)){
        return false;
    }

    uint8_t i = 0;
    while(strCommand[i] != '\0'){
        if((data->buffer[(data->fieldPosition[0]) + i]) != strCommand[i]){
            return false;
        }
        i++;
    }

    if((data->buffer[(data->fieldPosition[0]) + i]) == '\0'){
        return true;
    }
    else{
        return false;
    }
}

//-----------------------------------------------------------------------------
// Main
//-----------------------------------------------------------------------------

// REQUIRED: add processing for the shell commands through the UART here
void shell(void)
{
    putsUart0("Shell() called...\n");
    while(true)
    {
        // Default/Initialize user data from UART
        USER_DATA data ={0};

        getsUart0(&data);

        // Parse fields
        parseFields(&data);

        // Reboot command
        if(isCommand(&data, "reboot", 0)){
            rebootCaller();
        }
        // PS command
        else if(isCommand(&data, "ps", 0)){
            psCaller();
        }
        // IPCS command
        else if(isCommand(&data, "ipcs", 0)){
            ipcsCaller();
        }
        // KILL command
        else if(isCommand(&data, "kill", 1)){
            int32_t pid = getFieldInteger(&data, 1);
            killCaller(pid);
        }
        // PKILL command
        else if(isCommand(&data, "pkill", 1)){
            const char *proc_name = getFieldString(&data, 1);
            pkillCaller(proc_name);
        }
        // PI command
        else if(isCommand(&data, "pi", 1)){
            char *tmp = getFieldString(&data, 1);
            if(tmp[0] == 'o' && tmp[1] == 'n' && tmp[2] == '\0')
            {
                piCaller(true);
            }
            else if(tmp[0] == 'o' && tmp[1] == 'f' && tmp[2] == 'f' && tmp[3] == '\0')
            {
                piCaller(false);
            }
            else
            {
                putsUart0("Invalid Command\n");
            }
        }
        // PREEMPT command
        else if(isCommand(&data, "preempt", 1)){
            char *tmp = getFieldString(&data, 1);
            if(tmp[0] == 'o' && tmp[1] == 'n' && tmp[2] == '\0')
            {
                preemptCaller(true);
            }
            else if(tmp[0] == 'o' && tmp[1] == 'f' && tmp[2] == 'f' && tmp[3] == '\0')
            {
                preemptCaller(false);
            }
            else
            {
                putsUart0("Invalid Command\n");
            }
        }
        // SCHED command
        else if(isCommand(&data, "sched", 1)){
            char *tmp = getFieldString(&data, 1);
            if(tmp[0] == 'p' && tmp[1] == 'r' && tmp[2] == 'i' && tmp[3] == 'o' && tmp[4] == '\0')
            {
                schedCaller(true);
            }
            else if(tmp[0] == 'r' && tmp[1] == 'r' && tmp[2] == '\0')
            {
                schedCaller(false);
            }
            else
            {
                putsUart0("Invalid Command\n");
            }
        }
        // PIDOF command
        else if(isCommand(&data, "pidof", 1)){
            const char *proc_name = getFieldString(&data, 1);
            pidofCaller(proc_name);
        }
        // RUN command
        else if(isCommand(&data, "run", 1)){
            const char *proc_name = getFieldString(&data, 1);
            runCaller(proc_name);
        }
        // Invalid command
        else{
            putsUart0("Invalid Command\n");
        }
    }
}
