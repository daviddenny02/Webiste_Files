// David Denny, 1001915603
// RTOS Project
// Helper Functions

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL
// Target uC:       TM4C123GH6PM
// System Clock:    40MHz

// These are simply helper functions used throughout the implementation of the RTOS
// Most of these are printing functions for Debug and Demonstration purposes

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include "clock.h"
#include "tm4c123gh6pm.h"
#include "wait.h"
#include "uart0.h"
#include "asm.h"
#include "faults.h"

// GPIO masks
#define RED_LED_MASK 2

// Max UART command widths
#define MAX_CHARS 80
#define MAX_FIELDS 5

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

// 32-bit Integer to 8-bit Hex Converter
void int32_to_hex(uint32_t value, char *str)
{
    uint8_t i;
    const char hex_digits[] = "0123456789ABCDEF";
    for (i = 0; i < 8; i++)
    {
        // Shift top nibble down and mask
        uint8_t digit = (value >> ((7 - i) * 4)) & 0xF;
        str[i] = hex_digits[digit];
    }
    str[8] = '\0';
    return;
}

// Helper function to print 32-bit values in Hexadecimal format
void print_hex(uint32_t value)
{
    const char hex_digits[] = "0123456789ABCDEF";
    char str[9];
    uint8_t i;

    for (i = 0; i < 8; i++)
    {
        uint8_t digit = (value >> ((7 - i) * 4)) & 0xF;
        str[i] = hex_digits[digit];
    }
    str[8] = '\0';

    putsUart0(str);
}


char* int32_to_string(uint32_t pid)
{
    static char buf[32] = {0};
    int i = 30;

    if (pid == 0)
    {
        buf[30] = '0';
        buf[31] = '\0';
        return &buf[30];
    }

    for (; pid && i; --i, pid /= 10)
    {
        buf[i] = "0123456789abcdef"[pid % 10];
    }

    return &buf[i+1];
}

// This function prints the requisite values when a fault occurs
//   If a fault occurs with a misaligned PC, then a Hard Fault will occur
//   when attempting to print the offending instruction!
void FaultDecoder(void)
{
    uint32_t *psp = (uint32_t*) getPsp();
    uint32_t *msp = (uint32_t*) getMsp();

    uint32_t r0   = *(psp + 0);             // *(psp + 0), stacked R0
    uint32_t r1   = *(psp + 1);             // *(psp + 1), stacked R1
    uint32_t r2   = *(psp + 2);             // stacked R2
    uint32_t r3   = *(psp + 3);             // stacked R3
    uint32_t r12  = *(psp + 4);             // stacked R12
    uint32_t lr   = *(psp + 5);             // stacked LR (link register)
    uint32_t pc   = *(psp + 6);             // stacked PC (faulting instruction)
    uint32_t xpsr = *(psp + 7);             // stacked xPSR
    uint32_t cfsr  = NVIC_FAULT_STAT_R;     // Configurable Fault Status, pg. 177
    uint32_t hfsr  = NVIC_HFAULT_STAT_R;    // Hard Fault Status, pg. 183
    uint32_t mmfar = NVIC_MM_ADDR_R;        // MemManage Fault Address, pg. 184
    uint32_t bfar  = NVIC_FAULT_ADDR_R;     // Bus Fault Address, pg. 185

    char psp_str[9];
    char msp_str[9];
    char r0_str[9];
    char r1_str[9];
    char r2_str[9];
    char r3_str[9];
    char r12_str[9];
    char lr_str[9];
    char pc_str[9];
    char xpsr_str[9];
    char cfsr_str[9];
    char hfsr_str[9];
    char mmfar_str[9];
    char bfar_str[9];

    int32_to_hex((uint32_t)psp, psp_str);
    int32_to_hex((uint32_t)msp, msp_str);
    int32_to_hex(r0, r0_str);
    int32_to_hex(r1, r1_str);
    int32_to_hex(r2, r2_str);
    int32_to_hex(r3, r3_str);
    int32_to_hex(r12, r12_str);
    int32_to_hex(lr, lr_str);
    int32_to_hex(pc, pc_str);
    int32_to_hex(xpsr, xpsr_str);
    int32_to_hex(cfsr, cfsr_str);
    int32_to_hex(hfsr, hfsr_str);
    int32_to_hex(mmfar, mmfar_str);
    int32_to_hex(bfar, bfar_str);

    putsUart0("PSP:   0x"); putsUart0(psp_str);   putsUart0("\n");
    putsUart0("MSP:   0x"); putsUart0(msp_str);   putsUart0("\n");
    putsUart0("R0:    0x"); putsUart0(r0_str);    putsUart0("\n");
    putsUart0("R1:    0x"); putsUart0(r1_str);    putsUart0("\n");
    putsUart0("R2:    0x"); putsUart0(r2_str);    putsUart0("\n");
    putsUart0("R3:    0x"); putsUart0(r3_str);    putsUart0("\n");
    putsUart0("R12:   0x"); putsUart0(r12_str);   putsUart0("\n");
    putsUart0("PC:    0x"); putsUart0(pc_str);    putsUart0("\n");
    putsUart0("LR:    0x"); putsUart0(lr_str);    putsUart0("\n");
    putsUart0("XPSR:  0x"); putsUart0(xpsr_str);  putsUart0("\n");
    putsUart0("CFSR:  0x"); putsUart0(cfsr_str);  putsUart0(" (Fault Config Status)\n");
    putsUart0("HFSR:  0x"); putsUart0(hfsr_str);  putsUart0(" (Hard Fault Status)\n");
    putsUart0("MMFAR: 0x"); putsUart0(mmfar_str); putsUart0(" (Mem/Manage Fault Address)\n");
    putsUart0("BFAR:  0x"); putsUart0(bfar_str);  putsUart0(" (Bus Fault Address)\n");

    uint16_t offend_one = *((uint16_t*)(pc));
    char offend_one_str[9];
    int32_to_hex(offend_one, offend_one_str);

    putsUart0("\nOffending Instruction (PC): ");
    putsUart0(offend_one_str);
    putsUart0("\n");

    return;
}
