// David Denny, 1001915603
// RTOS Project
// Kernel Functionality

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "mm.h"
#include "kernel.h"
#include <stdbool.h>
#include <stdlib.h>
#include "clock.h"
#include "tm4c123gh6pm.h"
#include "wait.h"
#include "uart0.h"
#include "asm.h"
#include "functions.h"
#include "shell.h"

//-----------------------------------------------------------------------------
// RTOS Defines and Kernel Variables
//-----------------------------------------------------------------------------

// mutex
typedef struct _mutex
{
    bool lock;
    uint8_t queueSize;
    uint8_t processQueue[MAX_MUTEX_QUEUE_SIZE];
    uint8_t lockedBy;
} mutex;
mutex mutexes[MAX_MUTEXES];

// semaphore
typedef struct _semaphore
{
    uint8_t count;
    uint8_t queueSize;
    uint8_t processQueue[MAX_SEMAPHORE_QUEUE_SIZE];
} semaphore;
semaphore semaphores[MAX_SEMAPHORES];

// Task States
#define STATE_INVALID           0 // no task
#define STATE_UNRUN             1 // task has never been run
#define STATE_READY             2 // has run, can resume at any time
#define STATE_DELAYED           3 // has run, but now awaiting timer
#define STATE_BLOCKED_SEMAPHORE 4 // has run, but now blocked by semaphore
#define STATE_BLOCKED_MUTEX     5 // has run, but now blocked by mutex
#define STATE_KILLED            6 // has been killed

// sysTick Globals
static volatile uint8_t cpu_active_buffer = 0;  // Determines what buffer is being measured
static volatile uint32_t sys_ms_counter = 0;
static volatile uint32_t last_us_in_window = 0; // Latest timestamp (dependent on when ps is called)
extern int32_t memTable[32][2];

// task
uint8_t taskCurrent = 0;          // index of last dispatched task
uint8_t taskCount = 0;            // total number of valid tasks

// control
bool priorityScheduler = true;    // priority (true) or round-robin (false)
bool priorityInheritance = false; // priority inheritance for mutexes
bool preemption = false;          // preemption (true) or cooperative (false) // was false

// tcb
#define NUM_PRIORITIES   8
struct _tcb
{
    uint8_t state;                 // see STATE_ values above
    void *pid;                     // used to uniquely identify thread (add of task fn)
    void *spInit;                  // original top of stack
    void *sp;                      // current stack pointer
    uint8_t priority;              // 0=highest
    uint8_t currentPriority;       // 0=highest (needed for pi)
    uint32_t ticks;                // ticks until sleep complete
    uint8_t srd[NUM_SRAM_REGIONS]; // MPU subregion disable bits
    char name[16];                 // name of task used in ps command
    uint8_t mutex;                 // index of the mutex in use or blocking the thread
    uint8_t semaphore;             // index of the semaphore that is blocking the thread
    uint32_t cpu_us[2];            // a/b window for CPU Time % tracking with the ps shell command
    uint32_t stackBytes;
} tcb[MAX_TASKS];

volatile uint8_t currentTask = 0xFF; // Added global to track the current task
static uint8_t priorityQueue[NUM_PRIORITIES] = {0}; // Second index to go through tasks of the same priority level

// Mini-Project Register Masks and Bitband Aliases
#define RED_LED             (*((volatile uint32_t *)(0x42000000 + (0x400243FC-0x40000000)*32 + 0*4))) // Port E0
#define ORANGE_LED          (*((volatile uint32_t *)(0x42000000 + (0x400043FC-0x40000000)*32 + 2*4))) // Port A2
#define YELLOW_LED          (*((volatile uint32_t *)(0x42000000 + (0x400043FC-0x40000000)*32 + 3*4))) // Port A3
#define GREEN_LED           (*((volatile uint32_t *)(0x42000000 + (0x400043FC-0x40000000)*32 + 4*4))) // Port A4
#define SCB_BASE            0xE000ED00
#define SCB_CFSR_R          (*((volatile uint32_t *)(SCB_BASE + 0x28)))  // Configurable Fault Status Reg

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

bool initMutex(uint8_t mutex)
{
    bool ok = (mutex < MAX_MUTEXES);
    if (ok)
    {
        mutexes[mutex].lock = false;
        mutexes[mutex].lockedBy = 0;
    }
    return ok;
}

bool initSemaphore(uint8_t semaphore, uint8_t count)
{
    bool ok = (semaphore < MAX_SEMAPHORES);
    {
        semaphores[semaphore].count = count;
    }
    return ok;
}

// Return the measured time from the 1sec interval
//   Ping-pong method, 2 different windows alternating
static uint32_t getWindowTime(void)
{
    uint32_t reload = NVIC_ST_RELOAD_R + 1U;
    uint32_t val = NVIC_ST_CURRENT_R;
    uint32_t ms_mod = sys_ms_counter % 1000U;

    // Integer math, minimal division computation
    uint32_t sub_ms_us = ((reload - val) * 1000U) / reload;
    uint32_t time = ms_mod * 1000U + sub_ms_us;
    return time;
}


// REQUIRED: initialize systick for 1ms system timer
void initRtos(void)
{
    uint8_t i;
    // no tasks running
    taskCount = 0;
    currentTask = 0;
    // clear out tcb records
    for (i = 0; i < MAX_TASKS; i++)
    {
        tcb[i].state = STATE_INVALID;
        tcb[i].pid = 0;
    }

    // Reload = (System Clock / 1000) - 1
    uint64_t reload = (40000000UL / 1000ULL) - 1ULL;

    // Initialize sysTick for 1ms timer
    NVIC_ST_RELOAD_R = (uint32_t)reload;
    NVIC_ST_CURRENT_R = 0;
    NVIC_ST_CTRL_R = (1<<2) | (1<<1) | 1;
}

// This function returns the lowest currentPriority from all
//   tasks that are READY or UNRUN. Returns 0xFF if none found.
uint8_t getLowestPriority(void)
{
    uint8_t lowestPriority = 0xFF;
    int32_t i;
    for (i = 0; i < MAX_TASKS; ++i)
    {
        if (tcb[i].state == STATE_READY || tcb[i].state == STATE_UNRUN)
        {
            if(priorityInheritance) // Priority Inheritance Enabled
            {
                if (tcb[i].currentPriority < lowestPriority)
                {
                    lowestPriority = tcb[i].currentPriority;
                }
            }
            else // Priority Inheritance Disabled
            {
                if (tcb[i].priority < lowestPriority)
                {
                    lowestPriority = tcb[i].priority;
                }
            }
        }
    }
    return lowestPriority;
}

// REQUIRED: Implement prioritization to NUM_PRIORITIES
uint8_t rtosScheduler(void)
{
    if (priorityScheduler) // Priority Scheduling
    {
        uint8_t lowestPriority = getLowestPriority();

        // If no ready/unrun tasks found, fall back to scanning and returning 0
        if (lowestPriority == 0xFF)
        {
            uint32_t i;
            for (i = 0; i < MAX_TASKS; ++i)
            {
                if (tcb[i].state == STATE_READY || tcb[i].state == STATE_UNRUN)
                    return (uint8_t)i;
            }
            return 0;
        }

        if (lowestPriority >= NUM_PRIORITIES)
        {
            // Something is wrong with priorities; pick any ready task to avoid lock.
            uint32_t i;
            for (i = 0; i < MAX_TASKS; ++i)
            {
                if (tcb[i].state == STATE_READY || tcb[i].state == STATE_UNRUN)
                    return (uint8_t)i;
            }
            return 0;
        }

        // Find all applicable task indices at that currentPriority
        uint8_t priorityTasks[MAX_TASKS];
        uint32_t numTasks = 0;
        uint32_t i;
        for (i = 0; i < MAX_TASKS; ++i)
        {
            if(priorityInheritance) // Priority Inheritance Enabled
            {
                if ((tcb[i].state == STATE_READY || tcb[i].state == STATE_UNRUN) && (tcb[i].currentPriority == lowestPriority))
                {
                    priorityTasks[numTasks++] = (uint8_t)i;
                }
            }
            else // Priority Inheritance Disabled
            {
                if ((tcb[i].state == STATE_READY || tcb[i].state == STATE_UNRUN) && (tcb[i].priority == lowestPriority))
                {
                    priorityTasks[numTasks++] = (uint8_t)i;
                }
            }
        }

        if (numTasks == 0)
        {
            uint32_t i;
            for (i = 0; i < MAX_TASKS; ++i)
            {
                if (tcb[i].state == STATE_READY || tcb[i].state == STATE_UNRUN)
                {
                    return (uint8_t)i;
                }
            }
            return 0;
        }

        // Use round-robin scheduling for each priority level
        uint8_t idx = priorityQueue[lowestPriority] % numTasks;
        priorityQueue[lowestPriority] = (priorityQueue[lowestPriority] + 1) % numTasks;
        return priorityTasks[idx];
    }
    else // Round-Robin Scheduling
    {
        static uint8_t task = 0xFF;
        bool ok = false;
        while (!ok)
        {
            task++;
            if (task >= MAX_TASKS)
                task = 0;
            ok = (tcb[task].state == STATE_READY || tcb[task].state == STATE_UNRUN);
        }
        return task;
    }
}

// REQUIRED: modify this function to start the operating system
void startRtos(void)
{
    putsUart0("startRtos() called...\n");

    currentTask = rtosScheduler();
    tcb[currentTask].state = STATE_READY;
    disableMpu();

    // Build SRD mask while privileged
    uint64_t srdMask = 0ULL;
    int32_t j;
    for (j = 0; j < NUM_SRAM_REGIONS; ++j)
    {
        srdMask |= ((uint64_t)tcb[currentTask].srd[j]) << (j * 8);
    }

    putsUart0("Applying srdBits...\n");
    applySramAccessMask(srdMask);
    enableMpu();

    // initialize CPU accounting
    cpu_active_buffer = 0;
    int32_t i;
    for (i = 0; i < MAX_TASKS; ++i) {
        tcb[i].cpu_us[0] = 0U;
        tcb[i].cpu_us[1] = 0U;
    }
    // capture the initial timestamp (safe to call SYSTICK_VAL here)
    last_us_in_window = getWindowTime();

    // Load the stack pointer and function pointer while still privileged
    uint32_t sp = (uint32_t)tcb[currentTask].sp;
    _fn fn = (_fn)tcb[currentTask].pid;

    // ensure Thumb LSB is set (function pointers must have it)
    uint32_t fnaddr = ((uint32_t)fn) | 1U;

    // I'm empirically losing info, including the PSP's set
    //   sp, when performing C calls. The below, single assembly
    //   function performs all required steps to initially start
    //   idle(), which includes atomically...
    //      setting PSP
    //      setting ASP
    //      switching to Unprivileged mode with TMPL
    //      jumping to idle()
    startIdle((uint32_t)sp, fnaddr);

    // Should never return once starting the RTOS if it does, halt.
    putsUart0("Error, RTOS Stopped, Stalling...\n");
    while(true);
}

// REQUIRED:
// add task if room in task list
// store the thread name
// allocate stack space and store top of stack in sp and spInit
// set the srd bits based on the memory allocation
bool createThread(_fn fn, const char name[], uint8_t priority, uint32_t stackBytes)
{
    bool ok = false;
    uint8_t i = 0;
    uint8_t j;
    bool found = false;
    if (taskCount < MAX_TASKS)
    {
        // Make sure fn not already in list (prevent reentrancy)
        while (!found && (i < MAX_TASKS))
        {
            found = (tcb[i++].pid ==  fn);
        }
        if (!found)
        {
            // Find first available tcb record
            i = 0;
            while (tcb[i].state != STATE_INVALID) {i++;} // All tcb entries are STATE_INVALID on startup
            tcb[i].state = STATE_UNRUN;
            tcb[i].pid = fn;
            tcb[i].priority = priority;
            tcb[i].currentPriority = tcb[i].priority;
            tcb[i].mutex = 0xFF; // Initialize mutex as "none" on startup
            tcb[i].cpu_us[0] = 0;
            tcb[i].cpu_us[1] = 0;
            for (j = 0; j < NUM_SRAM_REGIONS; j++)
            {
                tcb[i].srd[j] = 0;
            }

            uint8_t k = 0;
            while ((name[k] != '\0') && (k < 15))
            {
                tcb[i].name[k] = name[k];
                k++;
            }
            tcb[i].name[k] = '\0';

            // allocate stack memory
            void *baseAddr = mallocHeap(stackBytes);
            if (baseAddr == NULL)
            {
                tcb[i].state = STATE_INVALID;
                return false;
            }
            tcb[i].spInit = baseAddr;
            tcb[i].stackBytes = stackBytes;

            // compute stack pointer:
            // sp = base + requested_bytes - 64, aligned to 8 bytes
            //   maybe change this to -32 if things break

            // compute stack pointer:
            // sp = top - (8 words for R4-R11 + 8 words for HW frame) = top - 64
            uint32_t top = (uint32_t)baseAddr + stackBytes;
            uint32_t task_sp = top - ( (8 + 8) * sizeof(uint32_t) ); // top - 64
            task_sp &= ~7U;  // 8-byte align
            tcb[i].sp = (void*)task_sp;

            // calculate SRD mask for allocated region
            uint64_t srdMask = 0;
            addSramAccessWindow(&srdMask, (void *)baseAddr, stackBytes);

            // store SRD bytes per region in the TCB
            for (j = 0; j < NUM_SRAM_REGIONS; j++)
            {
                tcb[i].srd[j] = (srdMask >> (j * 8)) & 0xFF;
            }

            // increment task count
            taskCount++;
            currentTask++;
            ok = true;
        }
    }
    return ok;
}

// REQUIRED: modify this function to restart a thread
//   A lot of the logic in this function replicates createThread(),
//   but does so to revive a task that has already been killed
void restartThreadCaller(_fn fn)
{
    // Find the TCB index with this pid and STATE_KILLED
    int32_t idx = -1;
    uint32_t i;
    for (i = 0; i < MAX_TASKS; ++i)
    {
        if ((tcb[i].pid == (void*)fn) && (tcb[i].state == STATE_KILLED))
        {
            idx = (int32_t)i;
            break;
        }
    }

    if (idx == -1)
    {
        putsUart0("Error: No killed process found\n");
        return;
    }
    uint32_t stackBytes = tcb[idx].stackBytes;

    // Allocate memory with mallocHeap() again for that task
    void *baseAddr = mallocHeap(stackBytes);

    // Store base and compute stack pointer again
    tcb[idx].spInit = baseAddr;
    uint32_t taskTopAddress = (uint32_t)baseAddr + stackBytes;
    uint32_t task_sp = (taskTopAddress - 64); // top - 64
    task_sp &= ~7U;
    tcb[idx].sp = (void*)task_sp;
    uint64_t srdMask = 0;
    addSramAccessWindow(&srdMask, baseAddr, stackBytes);
    uint32_t j;
    for (j = 0; j < NUM_SRAM_REGIONS; ++j)
    {
        tcb[idx].srd[j] = (srdMask >> (j * 8)) & 0xFF;
    }

    // Reset all TCB characteristics
    tcb[idx].ticks = 0;
    tcb[idx].currentPriority = tcb[idx].priority;
    tcb[idx].mutex = 0xFF;
    tcb[idx].semaphore = 0xFF;
    tcb[idx].cpu_us[0] = 0;
    tcb[idx].cpu_us[1] = 0;
    tcb[idx].state = STATE_UNRUN;

    taskCount++;
    putsUart0("Restarting ");
    putsUart0(tcb[idx].name);
    putsUart0("...\n");
}


// REQUIRED: modify this function to stop a thread
// REQUIRED: remove any pending semaphore waiting, unlock any mutexes
void stopThreadCaller(_fn fn)
{
    // find the TCB index for this function pointer (pid)
    uint32_t i, m;
    int32_t found = -1;
    for (i = 0; i < MAX_TASKS; ++i)
    {
        if (tcb[i].state != STATE_INVALID && tcb[i].pid == (void*)fn)
        {
            found = (int32_t)i;
            break;
        }
    }

    if (found == -1)
    {
        putsUart0("Error: Task not found\n");
        return;
    }

    uint8_t idx = (uint8_t)found;
    putsUart0("Killing ");
    putsUart0(tcb[idx].name);
    putsUart0("...\n");

    // If task was queued for a Semaphore, dequeue/remove it
    if (tcb[idx].semaphore != 0xFF)
    {
        uint8_t sem = tcb[idx].semaphore;
        if (sem < MAX_SEMAPHORES)
        {
            uint8_t si, sj;
            for (si = 0; si < semaphores[sem].queueSize; ++si)
            {
                if (semaphores[sem].processQueue[si] == idx)
                {
                    // Shift the Semaphore queue as needed
                    for (sj = si + 1; sj < semaphores[sem].queueSize; ++sj)
                    {
                        semaphores[sem].processQueue[sj - 1] = semaphores[sem].processQueue[sj];
                    }
                    semaphores[sem].queueSize--;
                    break;
                }
            }
        }
        tcb[idx].semaphore = 0xFF;
    }

    // If task was queued for a Mutex, dequeue/remove it
    if (tcb[idx].mutex != 0xFF)
    {
        uint8_t mutexID = tcb[idx].mutex;
        if (mutexID < MAX_MUTEXES)
        {
            uint8_t mi, mj;
            for (mi = 0; mi < mutexes[mutexID].queueSize; ++mi)
            {
                if (mutexes[mutexID].processQueue[mi] == idx)
                {
                    // Shift the Semaphore queue as needed
                    for (mj = mi + 1; mj < mutexes[mutexID].queueSize; ++mj)
                    {
                        mutexes[mutexID].processQueue[mj - 1] = mutexes[mutexID].processQueue[mj];
                    }
                    mutexes[mutexID].queueSize--;
                    break;
                }
            }
        }
        tcb[idx].mutex = 0xFF;
    }

    // Free the memory allocated to the task
    if (tcb[idx].spInit != 0)
    {
        freeHeap(tcb[idx].spInit);
        tcb[idx].spInit = 0;
    }
    else
    {
        putsUart0("Error: freeHeap() failed\n");
    }

    // Reset TCB characteristics for the task to be killed, keep essential information
    tcb[idx].sp = 0;
    tcb[idx].ticks = 0;
    tcb[idx].mutex = 0xFF;
    tcb[idx].semaphore = 0xFF;
    for (i = 0; i < NUM_SRAM_REGIONS; ++i)
    {
        tcb[idx].srd[i] = 0;
    }
    tcb[idx].currentPriority = tcb[idx].priority;
    tcb[idx].state = STATE_KILLED;
    taskCount--;
    return;
}

// REQUIRED: modify this function to set a thread priority
void setThreadPriorityCaller(_fn fn, uint8_t priority)
{
    if (priority >= NUM_PRIORITIES)
    {
        putsUart0("Error: Invalid priority declared\n");
        return;
    }

    // Find the task to alter the priority of
    int32_t found = -1;
    uint32_t i;
    for (i = 0; i < MAX_TASKS; ++i)
    {
        if (tcb[i].state != STATE_INVALID && tcb[i].pid == (void*)fn)
        {
            found = (int32_t)i;
            break;
        }
    }

    if (found == -1)
    {
        putsUart0("Error: Task not found\n");
        return;
    }

    // Update the base and current priority
    uint8_t idx = (uint8_t)found;
    tcb[idx].priority = priority;
    tcb[idx].currentPriority = priority;

    // Trigger a pendSV to account for the new priority
    NVIC_INT_CTRL_R |= (1 << 28); // PendSV
    return;
}


// REQUIRED: modify this function to yield execution back to scheduler using pendsv
void yield(void)
{
    __asm("    SVC #7"); // The SVC identifier is 7
    __asm("    BX LR");
}

// REQUIRED: in coop and preemptive, modify this function to add support for task switching
// REQUIRED: process UNRUN and READY tasks differently
//   This is a helper function for pendSvIsr()
//   pendSvIsr() is located in asm.h/s
void makeDummyStack(uint8_t task, _fn fn)
{
    // Get the sp for the UNRUN task
    uint32_t sp = (uint32_t)tcb[task].sp;
    // Make sure the sp was allocated correctly in createThread()
    if (!(sp >= 0x20000000U) && (sp < 0x20008000U) || !((sp & 0x7U) == 0))
    {
        putsUart0("Error makeDummyStack: bad sp\n");
        return;
    }

    // Zero out R4-R11
    uint32_t *sp_ptr = (uint32_t*)sp;
    int32_t i;
    for (i = 0; i < 8; ++i)
    {
        sp_ptr[i] = 0x00000000;
    }

    // Zero out R1-R3, R12, LR, PC, XPSR
    //   Keep PC bit 1 set for thumb instruciton safety
    //   xPSR flag needs to be set or else Usage Fault
    uint32_t *dummyStack = (uint32_t*)(sp + 32);
    dummyStack[0] = 0x00000000;         // R0
    dummyStack[1] = 0x00000000;         // R1
    dummyStack[2] = 0x00000000;         // R2
    dummyStack[3] = 0x00000000;         // R3
    dummyStack[4] = 0x00000000;         // R12
    dummyStack[5] = 0xFFFFFFFD;         // LR/EXC
    dummyStack[6] = ((uint32_t)fn) | 1; // PC
    dummyStack[7] = 0x01000000;         // xPSR
    return;
}

// REQUIRED: in coop and preemptive, modify this function to add support for task switching
// REQUIRED: process UNRUN and READY tasks differently
//   This is a helper function for pendSvIsr()
//   pendSvIsr() is located in asm.h/s
uint32_t getNextTaskPsp(uint32_t currentPsp)
{
    if (currentTask < MAX_TASKS)  // valid running task index
    {
        //__asm volatile("CPSID i" : : : "memory");
        uint32_t now_us = getWindowTime();
        // compute delta in window, handling wrap inside 1-second window
        uint32_t delta_us = (now_us + 1000000U - last_us_in_window) % 1000000U;
        tcb[currentTask].cpu_us[cpu_active_buffer] += delta_us;
        // clamp safety (should not exceed 1,000,000)
        if (tcb[currentTask].cpu_us[cpu_active_buffer] > 1000000U)
            tcb[currentTask].cpu_us[cpu_active_buffer] = 1000000U;

        // advance last timestamp to now
        //__asm volatile("CPSIE i" : : : "memory");
        last_us_in_window = now_us;
    }

    // Update the sp of the currentTask prior to switching
    tcb[currentTask].sp = (void*)currentPsp;

    // Grab the next task with the scheduler
    uint8_t next = currentTask;
    next = rtosScheduler();

    // If the next task to run is the same, just return the currentPsp
    //   Prior to implementing priorities, this should only occur if
    //   idle() is the only task created with createThread()
    if (next == currentTask) {
        return currentPsp;
    }

    // Create dummy stack if the state is UNRUN
    if (tcb[next].state == STATE_UNRUN) {
        // Make sure the sp was allocated correctly in createThread()
        if (tcb[next].sp == 0) {
            // Do not switch to an unallocated sp
            return currentPsp;
        }
        makeDummyStack(next, (_fn)tcb[next].pid);

        // Make the stack ready
        tcb[next].state = STATE_READY;
    }

    // Make sure the selected sp is valid
    uint32_t nextSp = (uint32_t)tcb[next].sp;
    if (!(nextSp >= 0x20000000U && nextSp < 0x20008000U) || (nextSp & 0x7U) != 0)
    {
        return currentPsp;
    }

    // Apply SRD bits for the next chosen task
    uint64_t srdMask = createNoSramAccessMask();
    int32_t j;
    for (j = 0; j < NUM_SRAM_REGIONS; ++j)
    {
        srdMask |= ((uint64_t)tcb[next].srd[j]) << (j * 8);
    }
    applySramAccessMask(srdMask);

    // Return the next task's sp, and update the currentTask
    currentTask = next;
    return nextSp;
}

// REQUIRED: modify this function to add support for the system timer
// REQUIRED: in preemptive code, add code to request task switch
void systickIsr(void)
{
    // decrement sleep ticks and record if any task woke
    bool wokeTaskFlag = false;
    int32_t i;
    for (i = 1; i < MAX_TASKS; i++)
    {
        if (tcb[i].state == STATE_DELAYED)
        {
            if (tcb[i].ticks > 0)
            {
                tcb[i].ticks--;
                if (tcb[i].ticks == 0)
                {
                    tcb[i].state = STATE_READY;
                    wokeTaskFlag = true;
                }
            }
        }
    }

    // Increment sysTick counter for preemption timer (1ms)
    sys_ms_counter++;

    // Flip windows each second
    if (sys_ms_counter >= 1000U)
    {
        uint8_t new_active = 1U - cpu_active_buffer;

        for (i = 0; i < MAX_TASKS; ++i)
        {
            tcb[i].cpu_us[new_active] = 0U;
        }

        cpu_active_buffer = new_active;
        sys_ms_counter = 0U;
        last_us_in_window = 0U;
    }

    // Decide if a PendSV is necessary:
    //   If in Cooperative <ode and if a task was awoken on this sysTick, trigger pendSV
    //   If in Preemption Mode...
    //     If using Priority Scheduling, only trigger a pendSV with a higher priority task
    //     If using Round-Robin Scheduling, just trigger a pendSV
    if (wokeTaskFlag) {
        if (!preemption)
        {
            // Cooperative Mode, trigger PendSV
            NVIC_INT_CTRL_R |= (1 << 28); // PendSV
        }
        else
        {
            // Preemptive Mode, determine how to Context Switch
            uint8_t candidatePriority = getLowestPriority();
            if (candidatePriority != 0xFF)
            {
                if (priorityScheduler) // Priority Scheduling
                {
                    // Default to triggering a PendSV if an error is encountered
                    if (currentTask >= MAX_TASKS)
                    {
                        NVIC_INT_CTRL_R |= (1 << 28); // PendSV
                    }
                    else
                    {
                        uint8_t cur_prio = priorityInheritance ? tcb[currentTask].currentPriority : tcb[currentTask].priority;
                        if (candidatePriority < cur_prio)
                        {
                            NVIC_INT_CTRL_R |= (1 << 28); // PendSV
                        }
                    }
                }
                else // Round-Robin Scheduling
                {
                    NVIC_INT_CTRL_R |= (1 << 28); // PendSV
                }
            }
        }
    }
    else
    {
        // No task was awoken on this sysTick, default to triggering a PendSV
        if (preemption && !priorityScheduler)
        {
            NVIC_INT_CTRL_R |= (1 << 28);
        }
    }
}

// Queue up the next task requesting to use the Mutex
static bool mutexEnqueue(uint8_t mutexID, uint8_t task)
{
    if (mutexes[mutexID].queueSize >= MAX_MUTEX_QUEUE_SIZE)
    {
        return false;
    }
    mutexes[mutexID].processQueue[ mutexes[mutexID].queueSize++ ] = task;
    return true;
}

// Dequeue a task from the Mutex queue
//   Return 0xFF if the Mutex queue is already empty
static uint8_t mutexDequeue(uint8_t mutexID)
{
    if (mutexID >= MAX_MUTEXES) return 0xFF;
    if (mutexes[mutexID].queueSize == 0)
        return 0xFF; // Mutex queue is empty

    // Take first element
    uint8_t next = mutexes[mutexID].processQueue[0];

    // Shifting/Rebuilding the Mutex queue
    uint8_t i;
    for (i = 1; i < mutexes[mutexID].queueSize; ++i)
    {
        mutexes[mutexID].processQueue[i - 1] = mutexes[mutexID].processQueue[i];
    }

    // Decrement size and clear the now-unused slot (optional nice-to-have)
    mutexes[mutexID].queueSize--;
    if (mutexes[mutexID].queueSize < MAX_MUTEX_QUEUE_SIZE)
    {
        mutexes[mutexID].processQueue[mutexes[mutexID].queueSize] = 0xFF;
    }

    return next;
}


// Queue up the next task requesting to use the Semaphore
static bool semaphoreEnqueue(uint8_t sem, uint8_t task_idx)
{
    if(sem >= MAX_SEMAPHORES)
    {
        return false;
    }

    if(semaphores[sem].queueSize >= MAX_SEMAPHORE_QUEUE_SIZE)
    {
        return false;
    }

    semaphores[sem].processQueue[semaphores[sem].queueSize++] = task_idx;
    return true;
}

// Dequeue a task from the Semaphore queue
//   Return 0xFF if the Mutex queue is already empty
static uint8_t semaphoreDequeue(uint8_t sem)
{
    if(sem >= MAX_SEMAPHORES)
    {
        return 0xFF;
    }
    if(semaphores[sem].queueSize == 0)
    {
        return 0xFF;
    }

    // Queue up the next task in the Semaphore queue
    uint8_t next = semaphores[sem].processQueue[0];

    // Shifting/Rebuilding the Semaphore queue
    uint8_t i;
    for (i = 1; i < semaphores[sem].queueSize; ++i)
    {
        semaphores[sem].processQueue[i - 1] = semaphores[sem].processQueue[i];
    }
    semaphores[sem].queueSize--;
    return next;
}

// Elevate the priority of a task to the same priority of a blocked, higher-priority task
static void promotePriority(uint8_t task, uint8_t newprio)
{
    if (task >= MAX_TASKS || newprio >= NUM_PRIORITIES) return;

    if (newprio < tcb[task].currentPriority)
    {
        tcb[task].currentPriority = newprio;

        // If this task is blocked on a Mutex, promote priorities through the priority levels
        if (tcb[task].state == STATE_BLOCKED_MUTEX)
        {
            uint8_t blockingMutex = tcb[task].mutex;
            if (blockingMutex < MAX_MUTEXES)
            {
                uint8_t blockingHolder = mutexes[blockingMutex].lockedBy;
                if (blockingHolder < MAX_TASKS && blockingHolder != task)
                {
                    // Recursively promote the priority of blocking tasks to clear this block
                    promotePriority(blockingHolder, newprio);
                }
            }
        }
    }
}

// Reverts the priority of a task to its base priority
static void restorePriority(uint8_t task)
{
    if (task >= MAX_TASKS) return;

    uint8_t currentPriority = tcb[task].priority;

    // For each mutex that this task currently holds, inspect its queue
    uint8_t i, j;
    for (i = 0; i < MAX_MUTEXES; ++i)
    {
        if (mutexes[i].lockedBy == task)
        {
            // Find the highest-priority waiter
            for (j = 0; j < mutexes[i].queueSize; ++j)
            {
                uint8_t waiter = mutexes[i].processQueue[j];
                if (waiter < MAX_TASKS)
                {
                    if (tcb[waiter].currentPriority < currentPriority)
                    {
                        currentPriority = tcb[waiter].currentPriority;
                    }
                }
            }
        }
    }
    // Set the task's currentPriority
    tcb[task].currentPriority = currentPriority;
}

// REQUIRED: modify this function to add support for the service call
// REQUIRED: in preemptive code, add code to handle synchronization primitives
void svCallIsr(void)
{
    uint32_t *svcStackPtr = (uint32_t*)(getPsp());          // Get the SVC stack from the PSP
    uint32_t svcPc = *(svcStackPtr + 6);                    // Get the PC from the SVC stack
    uint16_t svcInstruction = *(uint16_t*)(svcPc - 2);      // Get SVC Instruction from the stack
    uint8_t  svcNumber = (uint8_t)(svcInstruction & 0xFF);  // Get SVC Number from the lower 2 bytes

    switch (svcNumber)
    {
        case 7: // yield()
        {
            //putsUart0("yield() called...\n");
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        case 8: // sleep()
        {
            //putsUart0("sleep() called...\n");
            uint32_t ticks = svcStackPtr[0];
            tcb[currentTask].ticks = ticks;
            tcb[currentTask].state = STATE_DELAYED;
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        case 9: // lock()
        {
            uint8_t mutexID = (uint8_t) svcStackPtr[0];
            if (mutexID >= MAX_MUTEXES)
            {
                putsUart0("Invalid Mutex ID\n");
                break;
            }

            if (!mutexes[mutexID].lock)
            {
                mutexes[mutexID].lock = true;
                mutexes[mutexID].lockedBy = currentTask;
                mutexes[mutexID].queueSize = 0;
                tcb[currentTask].mutex = mutexID;
            }
            else
            {
                // Mutex already locked. Block current task and enqueue it.
                tcb[currentTask].state = STATE_BLOCKED_MUTEX;
                tcb[currentTask].mutex = mutexID;

                if (!mutexEnqueue(mutexID, currentTask))
                {
                    putsUart0("Mutex queue full\n");
                }

                if (priorityInheritance)
                {
                    uint8_t holder = mutexes[mutexID].lockedBy;
                    if (holder < MAX_TASKS)
                    {
                        uint8_t waiter_prio = tcb[currentTask].currentPriority;
                        promotePriority(holder, waiter_prio);
                    }
                }
                // Trigger a PendSV
                SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
                NVIC_INT_CTRL_R |= (1<<28);          // PendSV
            }
            break;
        }

        case 10: // unlock()
        {
            uint8_t mutexID = (uint8_t) svcStackPtr[0];
            if (mutexID >= MAX_MUTEXES)
            {
                putsUart0("Error in unlock(): Invalid mutex index\n");
                while(true);
            }

            if (!mutexes[mutexID].lock)
            {
                putsUart0("Error in unlock(): Mutex already unlocked\n");
                while(true);
            }

            // Check mutex ownership
            if (mutexes[mutexID].lockedBy != currentTask)
            {
                putsUart0("Error in unlock(): Callee not owner of mutex...\n");
                while(true);
            }

            // If no waiter, just release and restore priority
            if (mutexes[mutexID].queueSize == 0)
            {
                mutexes[mutexID].lock = false;
                mutexes[mutexID].lockedBy = 0xFF;
                tcb[currentTask].mutex = 0xFF;
                restorePriority(currentTask);
            }
            else
            {
                // Dequeue next waiting task and hand mutex to it
                uint8_t next = mutexDequeue(mutexID);
                if (next == 0xFF)
                {
                    putsUart0("Error: Invalid Mutex Queued...\n");
                    while(true);
                }
                // Assign mutex to next task that needs it
                mutexes[mutexID].lock = true;
                mutexes[mutexID].lockedBy = next;
                tcb[next].mutex = mutexID;
                tcb[next].state = STATE_READY;
                restorePriority(currentTask);

                // Trigger a PendSV
                NVIC_INT_CTRL_R |= (1<<28);
            }
            break;
        }

        case 11: // wait()
        {
            // Get the Semaphore ID
            uint8_t semID = (uint8_t) svcStackPtr[0];
            if(semID >= MAX_SEMAPHORES)
            {
                putsUart0("Error: invalid semID\n");
                break;
            }

            if(semaphores[semID].count > 0)
            {
                // Use the Semaphore if available
                semaphores[semID].count--;
            }
            else // Semaphore unavailable
            {
                tcb[currentTask].state = STATE_BLOCKED_SEMAPHORE;
                tcb[currentTask].semaphore = semID;

                // Queue the next task requesting the Semaphore
                //   Else the Semaphore queue is full
                if (!semaphoreEnqueue(semID, currentTask))
                {
                    putsUart0("Error: semaphore queue full\n");
                    while(true);
                }

                // Trigger a pendSV
                SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
                NVIC_INT_CTRL_R |= (1 << 28);        // PendSV
            }
            break;
        }

        case 12: // post()
        {
            // Get the Semaphore ID
            uint8_t semID = (uint8_t) svcStackPtr[0];
            if (semID >= MAX_SEMAPHORES)
            {
                putsUart0("Error: invalid semID\n");
                break;
            }

            // If there is a waiter, hand the token directly to the oldest waiter
            if (semaphores[semID].queueSize > 0)
            {
                // Dequeue the Semaphore
                uint8_t next = semaphoreDequeue(semID);
                if (next == 0xFF)
                {
                    putsUart0("Error: dequeue error\n");
                    while(true);
                }

                // Update the status of the next task
                tcb[next].state = STATE_READY;
                tcb[next].semaphore = 0xFF; // clear

                // Trigger a pendSV
                NVIC_INT_CTRL_R |= (1 << 28);
            }
            else // There are no waiters in the Semaphore queue
            {
                if (semaphores[semID].count < 0xFF)
                {
                    semaphores[semID].count++;
                }
            }
            break;
        }

        case 13: // sched()
        {
            //putsUart0("sched() called...\n");
            uint32_t schedBool = svcStackPtr[0];
            sched(schedBool);
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        case 14: // reboot()
        {
            //putsUart0("sched() called...\n");
            reboot();
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        case 15: // ps()
        {
            //putsUart0("ps() called...\n");
            ps();
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        case 16: // ipcs()
        {
            //putsUart0("ipcs() called...\n");
            ipcs();
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        case 17: // kill()
        {
            //putsUart0("kill() called...\n");
            uint32_t pid = svcStackPtr[0];
            kill(pid);
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        case 18: // pkill()
        {
            //putsUart0("pkill() called...\n");
            const char *proc_name = (const char *)svcStackPtr[0];
            pkill(proc_name);
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        case 19: // pi()
        {
            //putsUart0("pi() called...\n");
            uint32_t piBool = svcStackPtr[0];
            pi(piBool);
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        case 20: // preempt()
        {
            //putsUart0("preempt() called...\n");
            uint32_t preemptBool = svcStackPtr[0];
            preempt(preemptBool);
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        case 21: // pidof()
        {
            //putsUart0("pidof() called...\n");
            const char *proc_name = (const char *)svcStackPtr[0];
            pidof(proc_name);
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        case 22: // run()
        {
            //putsUart0("run() called...\n");
            const char *proc_name = (const char *)svcStackPtr[0];
            run(proc_name);
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        case 23: // setThreadPriorityCaller()
        {
            //putsUart0("setThreadPriorityCaller() called...\n");
            _fn fn = (_fn)svcStackPtr[0];
            uint8_t priority = (uint8_t)svcStackPtr[1];
            setThreadPriorityCaller(fn, priority);
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        case 24: // stopThreadCaller()
        {
            //putsUart0("stopThreadCaller() called...\n");
            _fn fn = (_fn)svcStackPtr[0];
            stopThreadCaller(fn);
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        case 25: // restartThreadCaller()
        {
            //putsUart0("restartThreadCaller() called...\n");
            _fn fn = (_fn)svcStackPtr[0];
            restartThreadCaller(fn);
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }

        default: // Invalid Service Call
        {
            putsUart0("Error: Invalid Service Call Identifier\n");
            SCB_CFSR_R |= (SCB_CFSR_R & 0xFF);   // clear MMFSR
            NVIC_INT_CTRL_R |= (1<<28);          // trigger pendSV call
            break;
        }
    }
}

// reboot() shell command
void reboot(void)
{
    putsUart0("Reboot Called\n");
    __asm ("    dsb");
    uint32_t reboot = NVIC_APINT_R & (0x700U);
    NVIC_APINT_R = (0x5FAUL << 16) | reboot | (1UL << 2);
    __asm ("    dsb");
    while(true)
    {
        __asm volatile ("    wfi");
    }
}

// Helper dictionary function to translate an enum state to its corresponding string
static char *stateString(uint8_t s)
{
    switch (s)
    {
        case STATE_INVALID:           return "INVALID";
        case STATE_UNRUN:             return "UNRUN";
        case STATE_READY:             return "READY";
        case STATE_DELAYED:           return "DELAYED";
        case STATE_BLOCKED_SEMAPHORE: return "BLOCKED_SEM";
        case STATE_BLOCKED_MUTEX:     return "BLOCKED_MUTEX";
        default:                      return "UNKNOWN";
    }
}

// ps() shell command
void ps(void)
{
    // Print Process Table
    putsUart0("Name            | State         | Prio | CPU % \n");
    putsUart0("===============================================\n");

    uint32_t i;
    for (i = 0; i < MAX_TASKS; ++i)
    {
        if ((tcb[i].state == STATE_INVALID) || (tcb[i].state == STATE_KILLED))
        {
            continue;
        }
        putsUart0(tcb[i].name);

        int32_t s;
        int32_t name_len = 0;
        while (name_len < 16 && tcb[i].name[name_len] != '\0') ++name_len;
        if (name_len < 16)
        {
            for (s = 0; s < (16 - name_len); ++s)
            {
                putcUart0(' ');
            }
        }
        putsUart0("| ");

        // Print States
        char *state = stateString(tcb[i].state);
        putsUart0(state);
        int32_t stateLength = 0;
        while (state[stateLength] != '\0') ++stateLength;
        if (stateLength < 13)
        {
            for (s = 0; s < (13 - stateLength); ++s) putcUart0(' ');
        }
        putsUart0(" | ");
        putsUart0(int32_to_string((int32_t)tcb[i].priority));
        putsUart0("    | ");

        // Calculate CPU time
        uint8_t completed = 1U - cpu_active_buffer;
        uint32_t us = tcb[i].cpu_us[completed];
        uint32_t pct_x100 = us / 100U;         // Total Milliseconds (from us)
        uint32_t pct_int = pct_x100 / 100U;    // Integer Part
        uint32_t pct_frac = pct_x100 % 100U;   // Fractional Part

        // Print CPU Time
        putsUart0(int32_to_string(pct_int));
        putcUart0('.');
        if (pct_frac < 10) putcUart0('0'); // Leading zero
        putsUart0(int32_to_string(pct_frac));
        putsUart0("%\n");
    }
    return;
}

// Helper function to print each task as a loop
static void printTask(uint8_t idx)
{
    if (idx >= MAX_TASKS)
    {
        putsUart0("-"); return;
    }

    if (tcb[idx].name[0] != '\0')
    {
        putsUart0(tcb[idx].name);
        putsUart0("(");
        putsUart0(int32_to_string((int32_t)idx));
        putsUart0(")");
    }
    else
    {
        putsUart0(int32_to_string((int32_t)idx));
    }
}

// ipcs() shell command
void ipcs(void)
{
    uint32_t i, j;
    putsUart0("Semaphores:\n");
    putsUart0("ID | Count | Waiting? | Waiters\n");
    putsUart0("=======================================================\n");

    for (i = 0; i < MAX_SEMAPHORES; ++i)
    {
        // Print the Semaphore table
        putsUart0(int32_to_string((int32_t)i));
        putsUart0("  | ");
        putsUart0(int32_to_string((int32_t)semaphores[i].count));
        putsUart0("     | ");
        if (semaphores[i].queueSize > 0)
        {
            putsUart0("Yes      | ");
        }
        else
        {
            putsUart0("No       | ");
        }

        if (semaphores[i].queueSize == 0)
        {
            putsUart0("-\n");
        }
        else
        {
            // print waiters
            for (j = 0; j < semaphores[i].queueSize; ++j)
            {
                uint8_t taskIndex = semaphores[i].processQueue[j];
                printTask(taskIndex);
                if (j + 1 < semaphores[i].queueSize)
                {
                    putsUart0(", ");
                }
            }
            putsUart0("\n");
        }
    }

    // Print the Mutex table
    putsUart0("\nMutexes:\n");
    putsUart0("ID | Locked? | Owner        | Waiting? | Waiters\n");
    putsUart0("=======================================================\n");

    for (i = 0; i < MAX_MUTEXES; ++i)
    {
        putsUart0(int32_to_string((int32_t)i));
        putsUart0("  | ");

        if (mutexes[i].lock)
        {
            putsUart0("Yes     | ");
        }
        else
        {
            putsUart0("No      | ");
        }

        // Print Owner
        if (mutexes[i].lockedBy < MAX_TASKS)
        {
            printTask(mutexes[i].lockedBy);
            putsUart0(" | ");
        }
        else
        {
            putsUart0("- | ");
        }

        // Print Waiting Status
        if (mutexes[i].queueSize > 0)
        {
            putsUart0("Yes      | ");
        }
        else
        {
            putsUart0("No       | ");
        }

        if (mutexes[i].queueSize == 0)
        {
            putsUart0("-\n");
        }
        else
        {
            for (j = 0; j < mutexes[i].queueSize; ++j)
            {
                uint8_t taskIndex = mutexes[i].processQueue[j];
                printTask(taskIndex);
                if (j + 1 < mutexes[i].queueSize)
                {
                    putsUart0(", ");
                }
            }
            putsUart0("\n");
        }
    }
    return;
}

// kill() shell command
void kill(uint32_t pid)
{
    _fn fn = (_fn)pid;
    stopThreadCaller(fn);
    return;
}

// pkill() shell command
void pkill(const char *proc_name)
{
    uint32_t i;
    for (i = 0; i < MAX_TASKS; ++i)
    {
        // Skip invalid slots
        if (tcb[i].state == STATE_INVALID)
        {
            continue;
        }

        // Compare tcb[i].name to proc_name
        const char *tcbEntry = tcb[i].name;
        const char *proc = proc_name;
        uint32_t idx = 0;
        bool matching = true;
        while (1)
        {
            char tcbEntryChar = tcbEntry[idx];
            char procChar = proc[idx];

            if (tcbEntryChar != procChar)
            {
                matching = false;
                break;
            }
            if (tcbEntryChar == '\0')
            {
                matching = true;
                break;
            }
            idx++;
        }

        // If a matching proc_name was found in TCB, kill it
        if (matching)
        {
            stopThreadCaller((_fn)tcb[i].pid);
            return;
        }
    }

    // No match found
    putsUart0("Process not found\n");
}

// pi() shell command
void pi(bool on)
{
    if(on)
    {
        priorityInheritance = true;
        putsUart0("Priority Inheritance Enabled\n");
    }
    else
    {
        priorityInheritance = false;
        putsUart0("Priority Inheritance Disabled\n");
    }
    return;
}

// preempt() shell command
void preempt(bool on)
{
    if(on)
    {
        putsUart0("Preemption Enabled\n");
        preemption = true;
    }
    else
    {
        putsUart0("Preemption Disabled\n");
        preemption = false;
    }
    return;
}

// sched() shell command
void sched(bool prio_on)
{
    if(prio_on)
    {
        priorityScheduler = true;
        putsUart0("Priority Scheduling Enabled...\n");
    }
    else
    {
        priorityScheduler = false;
        putsUart0("Round Robin Scheduling Enabled...\n");
    }
    return;
}

// pidof() shell command
void pidof(const char *proc_name)
{
    uint32_t i;
    for (i = 0; i < MAX_TASKS; ++i)
    {
        // Check if current TCB entry is empty
        if (tcb[i].state == STATE_INVALID)
        {
            continue;
        }

        // Comparing tcb[i].name to proc_name
        const char *tcbEntry = tcb[i].name;
        const char *proc = proc_name;
        uint32_t idx = 0;
        bool matchingProc;
        while(true)
        {
            char tcbEntryChar = tcbEntry[idx];
            char procChar = proc[idx];
            if (tcbEntryChar != procChar)
            {
                matchingProc = false;
                break;
            }
            if (tcbEntryChar == '\0')
            {
                matchingProc = true;
                break; // Match was found
            }
            idx++;
        }

        if (matchingProc)
        {
            putsUart0("Pid of ");
            putsUart0((char*)proc_name);
            putsUart0(" (decimal):     ");
            putsUart0(int32_to_string((uint32_t)tcb[i].pid));
            putsUart0("\n");
            putsUart0("Pid of ");
            putsUart0((char*)proc_name);
            putsUart0(" (hexadecimal): 0x");
            print_hex((uint32_t)tcb[i].pid);
            putsUart0("\n");
            return;
        }
    }
    // Matching process not found
    putsUart0("Process not found\n");
    return;
}

// run() shell command
void run(const char *proc_name)
{
    uint32_t i;
    for (i = 0; i < MAX_TASKS; ++i)
    {
        // Comparing tcb[i].name to proc_name
        if (tcb[i].state == STATE_INVALID)
        {
            continue;
        }
        const char *tcbEntry = tcb[i].name;
        const char *proc = proc_name;
        uint32_t idx = 0;
        bool match = true;
        while (true)
        {
            char tcbEntryChar = tcbEntry[idx];
            char procChar = proc[idx];
            if (tcbEntryChar != procChar)
            {
                match = false;
                break;
            }
            if (tcbEntryChar == '\0')
            {
                match = true; // Matching task found
                break;
            }
            idx++;
        }

        if (match)
        {
            putsUart0("Running ");
            putsUart0((char*)proc_name);
            putsUart0("\n");
            restartThreadCaller((_fn)tcb[i].pid);
            return;
        }
    }
    putsUart0("Process not found\n");
}

// Helper function for malloc_heap() and faultDecoder()
uint32_t getPid()
{
    return ((uint32_t)tcb[currentTask].pid);
}

// Helper function for MPU Faults to kill the faulting task
void killFaultingTask(void)
{
    stopThreadCaller((_fn)getPid());
    return;
}
