// David Denny, 1001915603
// RTOS Project
// Memory Management

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "mm.h"

#include <stdbool.h>
#include <stdlib.h>
#include "clock.h"
#include "wait.h"
#include "uart0.h"
#include "asm.h"
#include "functions.h"
#include "kernel.h"

int memTable[32][2]; // 4 Regions, 8 Sub-regions each, 32 total Sub-regions
// Table columns: PID_OWNER, LENGTH

// Address Mappings:
// =========================================
// Subregion | Hex Address | Decimal Address
// ========= | =========== | ===============
//  0        | 0x20000000  | 536870912
//  1        | 0x20000400  | 536871936
//  2        | 0x20000800  | 536872960
//  3        | 0x20000C00  | 536873984
//  4        | 0x20001000  | 536875008
//  5        | 0x20001400  | 536876032
//  6        | 0x20001800  | 536877056
//  7        | 0x20001C00  | 536878080
//  8        | 0x20002000  | 536879104
//  9        | 0x20002400  | 536880128
// 10        | 0x20002800  | 536881152
// 11        | 0x20002C00  | 536882176
// 12        | 0x20003000  | 536883200
// 13        | 0x20003400  | 536884224
// 14        | 0x20003800  | 536885248
// 15        | 0x20003C00  | 536886272
// 16        | 0x20004000  | 536887296
// 17        | 0x20004400  | 536888320
// 18        | 0x20004800  | 536889344
// 19        | 0x20004C00  | 536890368
// 20        | 0x20005000  | 536891392
// 21        | 0x20005400  | 536892416
// 22        | 0x20005800  | 536893440
// 23        | 0x20005C00  | 536894464
// 24        | 0x20006000  | 536895488
// 25        | 0x20006400  | 536896512
// 26        | 0x20006800  | 536897536
// 27        | 0x20006C00  | 536898560
// 28        | 0x20007000  | 536899584
// 29        | 0x20007400  | 536900608
// 30        | 0x20007800  | 536901632
// 31        | 0x20007C00  | 536902656

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

// Initialize privileges for the entire space
void initBackgroundRule(void)
{
    // Turn on the MPU and enable a background rule of full r/w/x access
    //   This MPU region is implicitly defined as region -1
    //   MPU_CTRL[0] = MPU on/off
    //   MPU_CTRL[2] = MPU Permissive Background Rule on/off
    NVIC_MPU_CTRL_R = (1 << 0) | (1 << 2);
    return;
}

// Turn on the MPU as needed
void enableMpu(void)
{
    NVIC_MPU_CTRL_R |= (1U << 0);
    return;
}

// Turn off the MPU as needed
void disableMpu(void)
{
    NVIC_MPU_CTRL_R &= ~(1 << 0);
    return;
}

// Initialize privileges for the flash region
void allowFlashAccess(void)
{
    NVIC_MPU_NUMBER_R = 0;        // Region 0
    NVIC_MPU_BASE_R = 0x00000000; // Base address for flash region

    // Turn on the region (1 << 0)
    // Set the region size to 256Kb (17 << 1)
    // Set the access privileges (b'011 = 3 << 24)
    //   Refer to Table 3-5 if these need to change later
    //   Privileged == RW
    //   Unprivileged == RW
    // Make sure eXecute Never is not enabled ~(0 << 28)
    NVIC_MPU_ATTR_R = (1 << 0) | (17 << 1) | (3 << 24);
    NVIC_MPU_ATTR_R &= ~(0 << 28);

    return;
}

// Initialize privileges for the peripheral/bitband region
void allowPeripheralAccess(void)
{
    NVIC_MPU_NUMBER_R = 1;        // Region 1
    NVIC_MPU_BASE_R = 0x40000000; // Base address for peripheral region

    // Turn on the region (1 << 0)
    // Set the region size to 64Mb (25 << 1)
    // Set the access privileges (b'011 = 3 << 24)
    //   Refer to Table 3-5 if these need to change later
    //   Privileged == RW
    //   Unprivileged == RW
    // Enable eXecute Never (1 << 28)
    NVIC_MPU_ATTR_R = (1 << 0) | (25 << 1) | (3 << 24) | (1 << 28);

    return;
}

// Initialize privileges for the SRAM region (base)
void allowSramAccess(void)
{
    NVIC_MPU_NUMBER_R = 2;        // Region 2
    NVIC_MPU_BASE_R = 0x20000000; // Base address for SRAM region

    // Turn on the region (1 << 0)
    // Set the region size to 32Kb (14 << 1)
    // Set the access privileges (b'011 = 3 << 24)
    //   Refer to Table 3-5 if these need to change later
    //   Privileged == RW
    //   Unprivileged == RW
    // Enable eXecute Never (1 << 28)
    NVIC_MPU_ATTR_R = (1 << 0) | (14 << 1) | (3 << 24) | (1 << 28);

    NVIC_MPU_NUMBER_R = 3;        // Region 3
    NVIC_MPU_BASE_R = 0x20000000; // Base address for SRAM region

    // Turn on the region (1 << 0)
    // Set the region size to 8Kb (12 << 1)
    // Set the access privileges (b'001 = 1 << 24)
    //   Refer to Table 3-5 if these need to change later
    //   Privileged == RW
    //   Unprivileged == No Access
    // Enable eXecute Never (1 << 28)
    NVIC_MPU_ATTR_R = (1 << 0) | (12 << 1) | (1 << 24) | (1 << 28);

    // Do the same for the rest of the SRAM regions
    NVIC_MPU_NUMBER_R = 4;        // Region 4
    NVIC_MPU_BASE_R = 0x20002000; // Base address for SRAM region
    NVIC_MPU_ATTR_R = (1 << 0) | (12 << 1) | (1 << 24) | (1 << 28);

    NVIC_MPU_NUMBER_R = 5;        // Region 5
    NVIC_MPU_BASE_R = 0x20004000; // Base address for SRAM region
    NVIC_MPU_ATTR_R = (1 << 0) | (12 << 1) | (1 << 24) | (1 << 28);

    NVIC_MPU_NUMBER_R = 6;        // Region 6
    NVIC_MPU_BASE_R = 0x20006000; // Base address for SRAM region
    NVIC_MPU_ATTR_R = (1 << 0) | (12 << 1) | (1 << 24) | (1 << 28);

    return;
}

// Update the SRD bits according to the current memTable
void applySramAccessMask(uint64_t srdBitMask)
{
    // For each SRAM MPU region, extract the correct byte from the mask
    uint32_t regionIndex;
    for (regionIndex = 0; regionIndex < 4; ++regionIndex)
    {
        uint32_t mpuRegion = 3 + regionIndex;
        NVIC_MPU_NUMBER_R = mpuRegion;

        uint32_t srd = (srdBitMask >> (regionIndex * 8)) & 0xFF;

        // Read current RASR, replace SRD field (bits [15:8])
        uint32_t rasr = NVIC_MPU_ATTR_R;
        rasr &= ~(0xFF << 8);
        rasr |= (srd << 8);

        // Write back
        NVIC_MPU_ATTR_R = rasr;
    }
    return;
}

// This function updates the srdBitMask, given a valid malloc_heap call
void addSramAccessWindow(uint64_t *srdBitMask, void *baseAdd, uint32_t size_in_bytes)
{
    uint32_t addr = (uint32_t)baseAdd;
    // Verify the given address
    if((addr < 0x20000000 || addr >= 0x20008000) || ((addr % 1024) != 0))
    {
        putsUart0("addSramAccessWindow() Error: Invalid address\n");
        return;
    }

    size_in_bytes = ((((size_in_bytes) + 1023) / 1024) * 1024);

    // Verify the given size
    if((size_in_bytes == 0) || (size_in_bytes > 32768) || (size_in_bytes % 1024 != 0))
    {
        putsUart0("addSramAccessWindow() Error: Invalid number of bytes\n");
        return;
    }

    // Compute block index and length
    uint32_t startingSubregion = (addr - 0x20000000) / 1024;
    uint32_t length     = size_in_bytes / 1024;

    // Make sure we don�t run past 32 KB
    if((startingSubregion + length) > 32)
    {
        putsUart0("Error: No room left\n");
        return;
    }

    // Generate the new srdBitMask
    uint64_t newSrdBitMask = ((1ULL << length) - 1ULL) << startingSubregion;

    // Update the srdBitMask
    *srdBitMask |= newSrdBitMask;
    // Clear lower 4 SRD bits (reserved by OS)
    *srdBitMask &= ~0xFULL;

    return;
}

// Enable all subregions, setting Unprivileged No Access privileges
uint64_t createNoSramAccessMask(void)
{
    // Apply the cleared SRD bits
    return 0x0000000000000000ULL;
}

// Print the current memory table
void printMemTable(void)
{
    putsUart0("Current Memory Table:\n");
    putsUart0("=====================\n");
    putsUart0("REG  |  PID  |  LEN  \n");
    putsUart0("=====================\n");
    uint32_t i;
    for(i = 31; i < 32; i--)
    {
        // Print SUB_REGION
        if(i == 0){
            putsUart0("0");
        }else{
            putsUart0(int32_to_string(i));
        }
        putsUart0("\t");

        // Print PID_OWNER
        if((memTable[i][0]) == -1){
            putsUart0("-1");
        }else if((memTable[i][0]) == 0){
            putsUart0("0");
        }else{
            putsUart0(int32_to_string(memTable[i][0]));
        }
        putsUart0("\t");

        // Print LENGTH
        if((memTable[i][1]) == -1){
            putsUart0("-1");
        }else if((memTable[i][1]) == 0){
            putsUart0("0");
        }else{
            putsUart0(int32_to_string(memTable[i][1]));
        }
        putsUart0("\n");

        // Stop loop
        if(i == 0) break;
    }
    return;
}

// REQUIRED: add your malloc code here and update the SRD bits for the current thread
// Allocate memory for a process
void* mallocHeap(uint32_t size_in_bytes)
{
    putsUart0("\nmalloc_heap() called...\n");

    // Error out when given an unusable number of bytes
    if((size_in_bytes <= 0) || (size_in_bytes > 28672))
    {
        putsUart0("mallocHeap() Error: Invalid number of bytes\n");
        return NULL;
    }

    // Round the value of bytes up to the nearest 1024 bytes
    uint32_t rounded_bytes = 0;
    uint32_t length = 0;
    uint32_t addr = 0x20000000;

    while (rounded_bytes < size_in_bytes)
    {
        rounded_bytes += 1024;
        length = (rounded_bytes / 1024);
    }

    uint32_t i, j;
    uint32_t skipFlag = 0;
    bool allocated = false; // Track if memory was allocated

    // Begin indexing at 0x20001000, since the first 4k are reserved for the OS
    for (i = 4; i < 32; i++)
    {
        if(memTable[i][0] == -1) // Empty block of memory found
        {
            if((i + length - 1) >= 32)
            {
                putsUart0("\nError: No space left\n");
                return NULL;
            }

            // Check that all required slots are free
            for (j = 0; j < length; j++)
            {
                if((memTable[i + j][0] != -1) || (memTable[i + j][1] != -1))
                {
                    skipFlag = 1;
                    break;
                }
            }

            // Skip if there is no room left in the memTable
            if(skipFlag == 1)
            {
                skipFlag = 0;
                continue;
            }

            // Found a valid subregion
            addr = addr + (i * 1024);
            for (j = 0; j < length; j++)
            {
                if(j == 0)
                {
                    memTable[i + j][0] = getPid();
                    memTable[i + j][1] = length;
                }
                else
                {
                    memTable[i + j][0] = getPid();
                    memTable[i + j][1] = 0;
                }
            }
            allocated = true;
            break;
        }
    }

    if(!allocated)
    {
        putsUart0("Error: Heap full\n");
        return NULL;
    }

    putsUart0("Allocating rounded ");
    putsUart0(int32_to_string(rounded_bytes));
    putsUart0(" bytes...\n");

    printMemTable();
    putsUart0("\nOutput address (base-10): ");
    putsUart0(int32_to_string(addr));
    putsUart0("\n");

    return (void*)addr;
}

// REQUIRED: add your free code here and update the SRD bits for the current thread
// Free memory from a running process
//   Usage: free_heap((void*)0x20004000);   // example address
//   Freeing memory just updates the memTable in this function
//     kill() will perform all MPU functions needed (aka clearing
//     the srdBits used by a process being killed).
void freeHeap(void* p)
{
    putsUart0("freeHeap() called...\n");

    uint32_t addr = (uint32_t)p;
    uint32_t subregion = ((addr - 0x20000000) / 1024);

    // Check if the address is valid, that memory actually is located there
    //   This will change to check if a valid PID is calling to free memory
    if((memTable[subregion][0] == -1) || (memTable[subregion][1] == -1))
    {
        putsUart0("Error: Invalid free address\n");
        return;
    }
    else
    {
        uint32_t length = (memTable[subregion][1]);
        uint32_t j;
        for (j = 0; j < length; j++)
        {
            if(memTable[subregion + j][0] != -1)
            {
                memTable[subregion + j][0] = -1;
                memTable[subregion + j][1] = -1;
            }
        }
    }
    // Print the updated memTable
    printMemTable();
    return;
}

// REQUIRED: initialize MPU here
void initMpu(void)
{
    // Clear the memTable on startup
    uint32_t i;
    for(i = 0; i < 32; i++)
    {
        memTable[i][0] = -1;
        memTable[i][1] = -1;
    }

    // Initialize Flash, Peripheral, and SRAM privileges here:
    allowFlashAccess();
    allowPeripheralAccess();
    allowSramAccess();
    initBackgroundRule(); // This function turns on the MPU! Turn it on LAST!

    // Apply the initial SRD bits for the SRAM regions
    //   Maybe remove this if I need to test things aside from the MPU
    applySramAccessMask(createNoSramAccessMask());

    // The below function can be used to test the unprivileged mode
    // when testing the MPU regions. Please note:
    //   If SRAM privileges have not been set for unprivileged mode
    //   (AP =/= 3, etc.), then an MPU fault WILL occur when trying
    //   to do basically anything in unprivileged mode beside running
    //   flash like a while(1);.

    // switchToUnprivileged();
    // putsUart0("Success!\n");
    // while(1);

    return;
}
