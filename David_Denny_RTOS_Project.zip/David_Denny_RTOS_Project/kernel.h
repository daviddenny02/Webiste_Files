// David Denny, 1001915603
// RTOS Project
// Kernel Functionality

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

#ifndef KERNEL_H_
#define KERNEL_H_

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdint.h>
#include <stdbool.h>

//-----------------------------------------------------------------------------
// RTOS Defines and Kernel Variables
//-----------------------------------------------------------------------------

// function pointer
typedef void (*_fn)();

// mutex
#define MAX_MUTEXES 1
#define MAX_MUTEX_QUEUE_SIZE 2
#define resource 0

// semaphore
#define MAX_SEMAPHORES 3
#define MAX_SEMAPHORE_QUEUE_SIZE 2
#define keyPressed 0
#define keyReleased 1
#define flashReq 2

// tasks
#define MAX_TASKS 12

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

bool initMutex(uint8_t mutex);
bool initSemaphore(uint8_t semaphore, uint8_t count);

void initRtos(void);
uint8_t getLowestPriority(void);
void startRtos(void);

bool createThread(_fn fn, const char name[], uint8_t priority, uint32_t stackBytes);
void restartThreadCaller(_fn fn);
void stopThreadCaller(_fn fn);
void setThreadPriorityCaller(_fn fn, uint8_t priority);

void yield(void);
void systickIsr(void);

static bool mutexEnqueue(uint8_t mid, uint8_t task);
static uint8_t mutexDequeue(uint8_t mid);
static bool semaphoreEnqueue(uint8_t sem, uint8_t task_idx);
static uint8_t semaphoreDequeue(uint8_t sem);
static void promotePriority(uint8_t task, uint8_t newprio);
static void restorePriority(uint8_t task);
void svCallIsr(void);
void makeDummyStack(uint8_t idx, _fn fn);
void reboot(void);
void ps(void);
static void printTask(uint8_t idx);
void ipcs(void);
void kill(uint32_t pid);
void pkill(const char *proc_name);
void pi(bool on);
void preempt(bool on);
void sched(bool prio_on);
void pidof(const char *proc_name);
void run(const char *proc_name);

uint32_t getPid();
void killFaultingTask(void);

#endif
