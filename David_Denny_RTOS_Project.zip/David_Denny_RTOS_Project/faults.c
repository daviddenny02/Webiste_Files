// David Denny, 1001915603
// RTOS Project
// RTOS Fault ISRs

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "faults.h"
#include "uart0.h"
#include "functions.h"
#include "kernel.h"

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

// REQUIRED: If these were written in assembly
//           omit this file and add a faults.s file

// REQUIRED: code this function
void mpuFaultIsr(void)
{
    putsUart0("MPU fault in process ");
    putsUart0(int32_to_string(getPid()));
    putsUart0("\n");
    FaultDecoder();
    killFaultingTask();
    NVIC_FAULT_STAT_R |= (NVIC_FAULT_STAT_R & 0xFF);   // clear MMFSR
    NVIC_INT_CTRL_R |= (1<<28);
}

// REQUIRED: code this function
void hardFaultIsr(void)
{
    putsUart0("Hard fault in process ");
    putsUart0(int32_to_string(getPid()));
    putsUart0("\n");
    FaultDecoder();
    while(1){} // Optional infinite loop upon faulting
}

// REQUIRED: code this function
void busFaultIsr(void)
{
    putsUart0("Bus fault in process ");
    putsUart0(int32_to_string(getPid()));
    putsUart0("\n");
    FaultDecoder();
    while(1){} // Optional infinite loop upon faulting
}

// REQUIRED: code this function
void usageFaultIsr(void)
{
    putsUart0("Usage fault in process ");
    putsUart0(int32_to_string(getPid()));
    putsUart0("\n");
    FaultDecoder();
    while(1){} // Optional infinite loop upon faulting
}
