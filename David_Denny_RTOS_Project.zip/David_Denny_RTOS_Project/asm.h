// David Denny, 1001915603
// RTOS Project
// Assembly Functions

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

#ifndef ASM_H_
#define ASM_H_

#include "kernel.h"

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

extern void setPsp(uint32_t psp);           // Declare the stack pointer to 0x20008000 (psp)
extern void setAsp(void);                   // Set ASP bit in control register, switching to PSP
extern uint32_t getPsp(void);               // Get the current value of the PSP
extern uint32_t getMsp(void);               // Get the current value of the MSP
extern void switchToUnprivileged(void);     // Switch to Unprivileged mode for testing
extern void pendSvIsr(void);
extern uint32_t getNextTaskPsp(uint32_t);   // PendSV Helper Function
extern void startIdle(uint32_t sp, uint32_t fnaddr);

extern void sleep(uint32_t tick);                               // SVC #8
extern void lock(int8_t mutex);                                 // SVC #9
extern void unlock(int8_t mutex);                               // SVC #10
extern void wait(int8_t semaphore);                             // SVC #11
extern void post(int8_t semaphore);                             // SVC #12
extern void schedCaller(bool prio_on);                          // SVC #13
extern void rebootCaller(void);                                 // SVC #14
extern void psCaller(void);                                     // SVC #15
extern void ipcsCaller(void);                                   // SVC #16
extern void killCaller(uint32_t pid);                           // SVC #17
extern void pkillCaller(const char *proc_name);                 // SVC #18
extern void piCaller(bool on);                                  // SVC #19
extern void preemptCaller(bool on);                             // SVC #20
extern void pidofCaller(const char *proc_name);                 // SVC #21
extern void runCaller(const char *proc_name);                   // SVC #22
extern void setThreadPriority(_fn fn, uint8_t priority);  // SVC #23
extern void stopThread(_fn fn);                           // SVC #24
extern void restartThread(_fn fn);                        // SVC #25

#endif
