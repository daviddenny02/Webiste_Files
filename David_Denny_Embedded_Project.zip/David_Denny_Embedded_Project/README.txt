// David Denny Embedded Project README

The project files located in this folder are the culmination of my Embedded Systems project.
The files included are simply the .c and .h files both original and essential to this
robot's operation. Not included are non-original files, such as used library files and
unnecessary compilation files. These were written in CCS using the C programming language.
Feel free to follow along as necessary. A brief discription of each file can be found below,
and are further explained in the included report:

lab8_David_Denny.c -- The primary main() implementation, implementing UART functionality
	using a respective UART library. Robot commands are acquired here.
led_interrupts.c -- LED and photoresistor implementation. Used to drive odometry, including
	distance calculations and wheel equalization. Relevant Hardware is instantiated here.
led_interrupts.h -- Header file for led_interrupts.c.
motor_commands.c -- Takes UART commands and drives the motor as needed.
motor_commands.h -- Header file for motor_commands.h.
motor_pwm.c -- Motor/DRV Hardware is instantiated here.
motor_pwm.h -- Header file for motor_pwm.c.
remote_interrupts.c -- Commands and Hardware for the IR Sensor is established here. This
	enables wireless control.
remote_interrupts.h -- Header file for remote_interrupts.c.
ultrasonic_interrupts.c -- Commands and Hardware for the Ultrasonic Sensor is established
	here. This allows for distance calculations. The Autonavigation protocol is also
	established here.
ultrasonic_interrupts.h -- Header file for ultrasonic_interrupts.c.
tm4c123gh6pm.h -- Header file for the TI Red Board. Register shorthands are declared here.