// Embedded 1 Lab 5
// David Denny, 1001915603

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL Evaluation Board
// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

// Hardware configuration:
// UART Interface:
//   U0TX (PA1) and U0RX (PA0) are connected to the 2nd controller
//   The USB on the 2nd controller enumerates to an ICDI interface and a virtual COM port
//   Configured to 115,200 baud, 8N1

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include "clock.h"
#include "uart0.h"
#include "motor_pwm.h"
#include "motor_commands.h"
#include "led_interrupts.h"
#include "remote_interrupts.h"
#include "ultrasonic_interrupts.h"
#include "tm4c123gh6pm.h"
#include "wait.h"

// Bitband aliases
#define SLEEP_PORT   (*((volatile uint32_t *)(0x42000000 + (0x400063FC-0x40000000)*32 + 6*4))) // Port C

// Port C masks
#define SLEEP_PORT_MASK 64

// Lab 4 defines
#define MAX_CHARS 80
#define MAX_FIELDS 5

// Global Variables:
int32_t distanceTemp = -1;

typedef struct _USER_DATA
{
    char buffer[MAX_CHARS + 1];
    uint8_t fieldCount;
    uint8_t fieldPosition[MAX_FIELDS];
    char fieldType[MAX_FIELDS];
} USER_DATA;

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

// Initialize Hardware
void initHw()
{
    // Initialize system clock to 40 MHz
    initSystemClockTo40Mhz();

    // Enable clocks
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R2; // Port C
    _delay_cycles(3);

    // Configure LED pins
    GPIO_PORTC_DIR_R |= SLEEP_PORT_MASK; // PC6
    GPIO_PORTC_DEN_R |= SLEEP_PORT_MASK; // Enable sleep pin
}

// This function gets an input string from user.
void getsUart0(USER_DATA* data)
{
    int count = 0;

    while(1)
    {
        char c = getcUart0();

        if((c == 8) || (c == 127))
        { // is c == backspace?
            if(count > 0)
            { // is count > 0?
                count--;
                continue;
            }
            else
            { // count !> 0
                continue;
            }
        }
        else
        { // c != backspace
            if(c == 13)
            { // is c == return?
                data->buffer[count] = '\0'; // Null terminator and return
                return;
            }
            else
            { // c != return
                if(c >= 32)
                { // is c >= space?
                    data->buffer[count] = c;
                    count++;
                    if(count == MAX_CHARS)
                    { // is the buffer full?
                        data->buffer[count] = 0; // Null terminator and return
                    }
                    else
                    { // the buffer is not full
                        continue;
                    }
                }
                else
                { // c != space
                    continue;
                }
            }
        }
    }
}

// This function parses the field, separating alpha, numerics, and delimiters
void parseFields(USER_DATA* data){

    int parser;
    int alphaFlag;
    int numericFlag;

    data->fieldCount = 0;

    for(parser = 0; parser < MAX_CHARS; parser++){

        alphaFlag = 0;
        numericFlag = 0;

        if((data->buffer[parser] == '\0') || (data->fieldCount == MAX_FIELDS)){ // end of the buffer string
            break;
        }
        else if(((data->buffer[parser] >= 65) && (data->buffer[parser] <= 90)) || ((data->buffer[parser] >= 97) && (data->buffer[parser] <= 122))){ // alpha found
            alphaFlag = 1;
        }
        else if((data->buffer[parser] >= 48) && (data->buffer[parser] <= 57)){ // numeric found
            numericFlag = 1;
        }
        else{ // delimiter found
            data->buffer[parser] = NULL;
            continue;
        }

        // Transition from start of string to alpha
        if((alphaFlag == 1) && ((data->fieldCount) == 0)){
            data->fieldPosition[(data->fieldCount)] = parser;
            data->fieldType[(data->fieldCount)] = 'a';
            data->fieldCount = (data->fieldCount) + 1;
            continue;
        }

        // Transition from delimiter to alpha
        else if((alphaFlag == 1) && ((data->buffer[(parser - 1)]) == NULL)){
            data->fieldPosition[(data->fieldCount)] = parser;
            data->fieldType[(data->fieldCount)] = 'a';
            data->fieldCount = (data->fieldCount) + 1;
            continue;
        }

        // Transition from start of string to numeric
        if((numericFlag == 1) && ((data->fieldCount) == 0)){
            data->fieldPosition[(data->fieldCount)] = parser;
            data->fieldType[(data->fieldCount)] = 'n';
            data->fieldCount = (data->fieldCount) + 1;
            continue;
        }

        // Transition from delimiter to numeric
        else if((numericFlag == 1) && ((data->buffer[(parser - 1)]) == NULL)){
            data->fieldPosition[(data->fieldCount)] = parser;
            data->fieldType[(data->fieldCount)] = 'n';
            data->fieldCount = (data->fieldCount) + 1;
            continue;
        }

    }
    return;
}

// This function returns the string in field (fieldNumber + 1)
// So fieldNumber = 2, the string in field 3 is returned
char* getFieldString(USER_DATA* data, uint8_t fieldNumber){
    // return 0 if the field is not a number, or if it is out of range
    if(((data->fieldType[fieldNumber]) != 'a') || (fieldNumber > data->fieldCount)){
        return 0;
    }
    else{ // Iterate to find the full number
        char tmpString[MAX_CHARS];
        int tmpStringCounter = 0;
        int fieldNumberCopy = (data->fieldPosition[fieldNumber]);
        while((data->buffer[fieldNumberCopy]) != NULL){
            tmpString[tmpStringCounter] = (data->buffer[fieldNumberCopy]);
            tmpStringCounter++;
            fieldNumberCopy++;
        }
        tmpString[tmpStringCounter] = '\0';
        return(tmpString);
    }
}

// This function returns the integer in field (fieldNumber + 1)
// So fieldNumber = 2, the integer in field 3 is returned
int32_t getFieldInteger(USER_DATA* data, uint8_t fieldNumber){
    // return 0 if the field is not a number, or if it is out of range
    if(((data->fieldType[fieldNumber]) != 'n') || (fieldNumber > data->fieldCount)){
        return 0;
    }
    else{ // Iterate to find the full number
        char tmpString[MAX_CHARS];
        int tmpStringCounter = 0;
        int fieldNumberCopy = (data->fieldPosition[fieldNumber]);
        while((data->buffer[fieldNumberCopy]) != NULL){
            tmpString[tmpStringCounter] = (data->buffer[fieldNumberCopy]);
            tmpStringCounter++;
            fieldNumberCopy++;
        }
        tmpString[tmpStringCounter] = '\0';
        return (atoi(tmpString));
    }
}

// This function returns true if a command and requisite arguments are passed in.
bool isCommand(USER_DATA* data, const char strCommand[], uint8_t minArguments){

    if((data->fieldCount) != (minArguments + 1)){
        return false;
    }

    uint8_t i = 0;
    while(strCommand[i] != '\0'){
        if((data->buffer[(data->fieldPosition[0]) + i]) != strCommand[i]){
            return false;
        }
        i++;
    }

    return true;
}

//-----------------------------------------------------------------------------
// Main
//-----------------------------------------------------------------------------

int main(void)
{
    // Initialize hardware
    initHw();
    initUart0();
    initMotors();
    initInterrupts();
    initRemoteInterrupts();
    initUltrasonic();

    // Step 3
    USER_DATA data ={0};

    // Disable sleep
    SLEEP_PORT = 1;

    while(true){
        getsUart0(&data);

        // Parse fields
        parseFields(&data);

        // Set command test -- From Lab 4
        bool valid = false;

        // Forward command (default (max) speed) =============================
        if(isCommand(&data, "forward", 0)){
            valid = true;
            putsUart0("Moving Forward\n");
            setForward(1023);
        }

        // Forward command (custom speed) ====================================
        if(isCommand(&data, "forward", 1)){
            valid = true;
            putsUart0("Moving Forward (custom speed)\n");

            // 0 = 0% duty cycle, 10000 = 100% duty cycle
            int32_t speed = getFieldInteger(&data, 1);
            float translation = (0.042 * speed) + 600;
            speed = translation;

            speed = checkSpeed(speed);
            setForward(speed);
        }

        // Forward command (custom speed, custom distance) ======================
        if(isCommand(&data, "forward", 2)){
            valid = true;
            putsUart0("Moving Forward (custom speed, custom distance)\n");

            clearCounters();

            // 0 = 0% duty cycle, 10000 = 100% duty cycle
            int32_t speed = getFieldInteger(&data, 1);
            distanceTemp = (getFieldInteger(&data, 2));

            float translation = (0.042 * speed) + 600;
            speed = translation;

            translation = 1.15 * (distanceTemp/14.4);
            distanceTemp = translation;
            if(distanceTemp >= 4){
                distanceTemp = distanceTemp - 3;
            }

            setDistance(distanceTemp);
            speed = checkSpeed(speed);
            setForward(speed);
            distanceTemp = -1;
        }

        // Reverse command (default (max) speed) =============================
        else if(isCommand(&data, "reverse", 0)){
            valid = true;
            putsUart0("Moving Backwards\n");
            setReverse(1023);
        }

        // Reverse command (custom speed) ====================================
        else if(isCommand(&data, "reverse", 1)){
            valid = true;
            putsUart0("Moving Backwards (custom speed)\n");

            // 0 = 0% duty cycle, 10000 = 100% duty cycle
            int32_t speed = getFieldInteger(&data, 1);
            float translation = (0.042 * speed) + 600;
            speed = translation;

            speed = checkSpeed(speed);
            setReverse(speed);
        }

        // Reverse command (custom speed, custom distance) ======================
        if(isCommand(&data, "reverse", 2)){
            valid = true;
            putsUart0("Moving Backwards (custom speed, custom distance)\n");

            clearCounters();

            // 0 = 0% duty cycle, 10000 = 100% duty cycle
            int32_t speed = getFieldInteger(&data, 1);
            distanceTemp = (getFieldInteger(&data, 2));

            float translation = (0.042 * speed) + 600;
            speed = translation;

            //translation = ((distance/14.4) * 0.80);
            translation = 1.1 * (distanceTemp/14.4);
            distanceTemp = translation;
            if(distanceTemp >= 4){
                distanceTemp = distanceTemp - 3;
            }

            setDistance(distanceTemp);
            speed = checkSpeed(speed);
            setReverse(speed);
            distanceTemp = -1;
        }


        // Counter-Clockwise command =========================================
        else if(isCommand(&data, "ccw", 0)){
            valid = true;
            putsUart0("Rotating Counter-Clockwise\n");
            setCCW();
        }

        // Counter-Clockwise command (custom angle) ==========================
        else if(isCommand(&data, "ccw", 1)){
            valid = true;
            putsUart0("Rotating Counter-Clockwise (custom angle)\n");

            clearCounters();

            distanceTemp = (getFieldInteger(&data, 1));

            float translation = (distanceTemp/12.75);
            distanceTemp = translation;

            setDistance(distanceTemp);
            setCCW();
            distanceTemp = -1;
        }

        // Clockwise command =================================================
        else if(isCommand(&data, "cw", 0)){
            valid = true;
            putsUart0("Rotating Clockwise\n");
            setCW();
        }

        // Clockwise command =================================================
        else if(isCommand(&data, "cw", 1)){
            valid = true;
            putsUart0("Rotating Clockwise (custom angle)\n");

            clearCounters();

            distanceTemp = (getFieldInteger(&data, 1));

            float translation = (distanceTemp/12.5);
            distanceTemp = translation;

            setDistance(distanceTemp);
            setCW();
            distanceTemp = -1;
        }

        // Stop command ======================================================
        else if(isCommand(&data, "stop", 0)){
            valid = true;
            putsUart0("Stopping...\n");
            setStop();
        }

        // Ping command ======================================================
        else if(isCommand(&data, "distance", 0)){
            valid = true;
            putsUart0("Pinging...\n");
            ping();
            //waitMicrosecond(1000000);
        }

        // Ping command ======================================================
        else if(isCommand(&data, "navigate", 0)){
            valid = true;
            if(getAutoFlag() == 0){
                putsUart0("Turning Autonavigation ON\n");
                enableAuto();
            }
            else{
                putsUart0("Turning Autonavigation OFF\n");
                disableAuto();
            }
        }

        // Invalid command ===================================================
        else if(!valid){
            putsUart0("Invalid Command\n");
        }
    }
}
