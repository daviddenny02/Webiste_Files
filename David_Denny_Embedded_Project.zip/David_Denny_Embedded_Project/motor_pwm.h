// Motor PWM Library
// David Denny

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL with LCD Interface
// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

// Hardware configuration:

// Motor Input 1 (PC5) drives Input 1 on Motor DRV, M0PWM7
// Motor Input 2 (PC4) drives Input 2 on Motor DRV, M0PWM6
// Motor Input 3 (PA6) drives Input 3 on Motor DRV, M1PWM2
// Motor Input 4 (PA7) drives Input 4 on Motor DRV, M1PWM3
// Sleep (PC6) drives sleep input on Motor DRV

// DRV Output 1 drives the positive right motor (+)
// DRV Output 2 drives the negative right motor (-)
// DRV Output 3 drives the positive left motor (+)
// DRV Output 4 drives the negative left motor (-)

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#ifndef MOTOR_PWM_H_
#define MOTOR_PWM_H_

#include <stdint.h>

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

void initMotors();

#endif
