// Ultrasonic Library
// David Denny

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL with LCD Interface
// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

// PD1 = Trigger = GPIO
// PD3 = Echo = WT3CCP1

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdint.h>

#ifndef ULTRASONIC_INTERRUPTS_H_
#define ULTRASONIC_INTERRUPTS_H_

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

void initUltrasonic();
void ping();
void ultrasonicIsr();
void findDistance();
void motionIsr();
void reconfigWTimer();

// Auto-nav commands
void autoNavTimerIsr();
void enableAuto();
void disableAuto();
void spinMode();
void enableSpinMode();
int getLeaveSpin();
void clearLeaveSpin();
int getAutoFlag();

#endif
