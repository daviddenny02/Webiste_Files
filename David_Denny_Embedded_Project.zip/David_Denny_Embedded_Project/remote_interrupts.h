// Remote Interrupt Library
// David Denny

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL with LCD Interface
// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

// Hardware configuration:

// IR detector (PC7) drives low edge interrupts

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdint.h>

#ifndef REMOTE_INTERRUPTS_H_
#define REMOTE_INTERRUPTS_H_

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

void initRemoteInterrupts();
void clearRemoteCommand();
void runRemoteCommand();
void remoteTimerIsr();
void remoteIsr();

#endif
