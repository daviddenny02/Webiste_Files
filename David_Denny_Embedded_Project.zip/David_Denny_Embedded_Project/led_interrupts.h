// LED Interrupt Library
// David Denny

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL with LCD Interface
// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

// Hardware configuration:

// Left Transistor (PD0) drives low edge interrupt
// Right Transistor (PD2) drives another low edge interrupt

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#ifndef LED_INTERRUPTS_H_
#define LED_INTERRUPTS_H_

#include <stdint.h>

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

void initInterrupts();
void ledIsr();
void timerLeftIsr();
void timerRightIsr();
void toggleRed();
void toggleBlue();
void incrementLeft();
void incrementRight();

#endif
