// Motor Commands Library
// David Denny

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL with LCD Interface
// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

// PD1 = Trigger = GPIO
// PD3 = Echo = WT3CCP1/GPIO
// Using Timer 0B (narrow)

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <remote_interrupts.h>
#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "uart0.h"
#include "wait.h"
#include "led_interrupts.h"
#include "motor_commands.h"

// Bitband aliases
#define TRIGGER_PORT    (*((volatile uint32_t *)(0x42000000 + (0x400073FC-0x40000000)*32 + 1*4))) // PD1
#define ECHO_PORT       (*((volatile uint32_t *)(0x42000000 + (0x400073FC-0x40000000)*32 + 3*4))) // PD3
#define MOTION_PORT     (*((volatile uint32_t *)(0x42000000 + (0x400043FC-0x40000000)*32 + 3*4))) // PE2

// Port C masks
#define REMOTE_PORT_MASK 128

// Port D masks
#define TRIGGER_PORT_MASK 2
#define ECHO_PORT_MASK 8
#define LEFT_LIGHT_MASK 1
#define RIGHT_LIGHT_MASK 4

// Port E masks
#define MOTION_PORT_MASK 4

// Port F masks
#define RED_LED      (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 1*4))) // PF1
#define RED_LED_MASK 2

// Global Variable
int i = 0;
int j = 0;
int pingFlag = 0;
int autoNavFlag = 0;
int autoNavCounter = 0;
int spinFlag = 0;
int spinCounter = 0;
int spinMax = 0;
int spinChoice = 0;
int leaveSpin = 0;

int alarmFlag = 0;
int alarmCounter = 0;

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

void initUltrasonic()
{
    // Using Narrow Timer 3A
    SYSCTL_RCGCTIMER_R |= SYSCTL_RCGCTIMER_R3;

    // Using Wide Timer 3B
    SYSCTL_RCGCWTIMER_R |= SYSCTL_RCGCWTIMER_R3;

    // Using GPIO port D and E
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R3 | SYSCTL_RCGCGPIO_R4;
    _delay_cycles(3);

    // Configure LED and pushbutton pins
    GPIO_PORTF_DEN_R |= RED_LED_MASK;
    GPIO_PORTF_DIR_R |= RED_LED_MASK;

    // Echo (input) configuration on PD3
    GPIO_PORTD_DEN_R |= ECHO_PORT_MASK;
    GPIO_PORTD_DIR_R &= ~(ECHO_PORT_MASK);

    // Trigger (output) configuration on PD1
    GPIO_PORTD_DEN_R |= TRIGGER_PORT_MASK;
    GPIO_PORTD_DIR_R |= TRIGGER_PORT_MASK;

    // Transistors drive pull-up registers
    GPIO_PORTD_PUR_R |= TRIGGER_PORT_MASK;

    // Motion Detector configuration on PE2 as an input
    GPIO_PORTE_DEN_R |= MOTION_PORT_MASK;
    GPIO_PORTE_DIR_R &= ~(MOTION_PORT_MASK);

    // Configure falling edge interrupts on Motion Detector inputs
    // (edge mode, single edge, rising edge, clear any interrupts, turn on)
    GPIO_PORTE_IS_R &= ~(MOTION_PORT_MASK);
    GPIO_PORTE_IBE_R &= ~(MOTION_PORT_MASK);
    GPIO_PORTE_IEV_R |= MOTION_PORT_MASK; // Rising edge detection
    GPIO_PORTE_ICR_R |= MOTION_PORT_MASK;
    GPIO_PORTE_IM_R |= MOTION_PORT_MASK;
    NVIC_EN0_R = 1 << (INT_GPIOE-16); // turn on interrupt 20 (Port E)

    // Configure Echo (PD3) for measurements
    //GPIO_PORTD_DIR_R &= ~(ECHO_PORT_MASK);
    GPIO_PORTD_AFSEL_R |= ECHO_PORT_MASK;            // select alternative functions for SIGNAL_IN pin
    GPIO_PORTD_PCTL_R &= ~(GPIO_PCTL_PD3_M);         // map alt fns to SIGNAL_IN
    GPIO_PORTD_PCTL_R |= GPIO_PCTL_PD3_WT3CCP1;
    GPIO_PORTD_DEN_R |= ECHO_PORT_MASK;              // enable bit 6 for digital input

    // Configure Wide Timer 3B as the time base
    WTIMER3_CTL_R &= ~TIMER_CTL_TBEN;                // turn-off counter before reconfiguring
    WTIMER3_CFG_R = 0x4;                             // configure as 32-bit counter (A only)
    WTIMER3_TBMR_R = TIMER_TBMR_TBCMR | TIMER_TBMR_TBMR_CAP | TIMER_TBMR_TBCDIR;
                                                     // configure for edge time mode, count up
    WTIMER3_CTL_R = TIMER_CTL_TBEVENT_BOTH;          // measure time from positive edge to negative edge
    WTIMER3_IMR_R = TIMER_IMR_CBEIM;                 // turn-on interrupts
    WTIMER3_TBV_R = 0;                               // zero counter for first period
    WTIMER3_CTL_R |= TIMER_CTL_TBEN;                 // turn-on counter
    NVIC_EN3_R = 1 << (INT_WTIMER3B-16-96);          // turn-on interrupt 117 (WTIMER3B)

    // Configure Timer 3A as the time base
    TIMER3_CTL_R &= ~TIMER_CTL_TAEN;                 // turn-off timer before reconfiguring
    TIMER3_CFG_R = TIMER_CFG_32_BIT_TIMER;           // configure as 32-bit timer (A+B)
    TIMER3_TAMR_R = TIMER_TAMR_TAMR_PERIOD;          // configure for one shot mode (count down)
    TIMER3_TAILR_R = 40000000;                       // set load value to 4e6 for 10 Hz interrupt rate
    TIMER3_IMR_R |= TIMER_IMR_TATOIM;                // turn-on interrupts
    NVIC_EN1_R = 0x00000008;                         // turn-on interrupt 51 (TIMER0B)
    TIMER3_CTL_R |= TIMER_CTL_TAEN;                  // Turn-on timer

    return;
}

void reconfigWTimer()
{
    // Configure Wide Timer 3B as the time base
    WTIMER3_CTL_R &= ~TIMER_CTL_TBEN;                // turn-off counter before reconfiguring
    WTIMER3_IMR_R = ~(TIMER_IMR_CBEIM);              // turn-off interrupts
    WTIMER3_CFG_R = 0x4;                             // configure as 32-bit counter (A only)
    WTIMER3_TBMR_R = TIMER_TBMR_TBCMR | TIMER_TBMR_TBMR_CAP | TIMER_TBMR_TBCDIR;
                                                     // configure for edge time mode, count up
    WTIMER3_CTL_R = TIMER_CTL_TBEVENT_BOTH;          // measure time from positive edge to negative edge
    WTIMER3_IMR_R = TIMER_IMR_CBEIM;                 // turn-on interrupts
    WTIMER3_TBV_R = 0;                               // zero counter for first period
    WTIMER3_CTL_R |= TIMER_CTL_TBEN;                 // turn-on counter
    NVIC_EN3_R = 1 << (INT_WTIMER3B-16-96);          // turn-on interrupt 117 (WTIMER3B)
}

void findDistance(int j)
{
    // 900mm  == 39720000
    // 1200mm == 39650000

    //i = ((40000000 - distance) * 0.0033);
    float pingDistance;
    pingDistance = ((0.00414 * j) + 5.437);
    if(pingDistance > 0)
    {
        i = pingDistance;
    }
    else
    {
        i = 0;
    }
    return;
}

// Ping command
void ping()
{
    GPIO_PORTC_IM_R &= ~(REMOTE_PORT_MASK);      // Turn off GPIO interrupt
    GPIO_PORTD_IM_R &= ~(LEFT_LIGHT_MASK);       // Turn off GPIO interrupt
    GPIO_PORTD_IM_R &= ~(RIGHT_LIGHT_MASK);      // Turn off GPIO interrupt
    GPIO_PORTE_IM_R &= ~(MOTION_PORT_MASK);      // Turn on GPIO interrupt
    reconfigWTimer();
    putsUart0("Ping called\n");
    TRIGGER_PORT = 1;
    waitMicrosecond(10);
    TRIGGER_PORT = 0;
    waitMicrosecond(1000000);
    return;
}

void ultrasonicIsr()
{
    if(pingFlag == 0){
        WTIMER3_TBV_R = 0;
    }
    else if(pingFlag == 1){
        j = WTIMER3_TBV_R;
        findDistance(j);
        WTIMER3_TBV_R = 0;
        GPIO_PORTC_IM_R |= REMOTE_PORT_MASK;      // Turn on GPIO interrupt
        GPIO_PORTD_IM_R |= LEFT_LIGHT_MASK;       // Turn on GPIO interrupt
        GPIO_PORTD_IM_R |= RIGHT_LIGHT_MASK;      // Turn on GPIO interrupt
    }

    pingFlag ^= 1;
    WTIMER3_ICR_R |= TIMER_ICR_CBECINT;
}

void motionIsr()
{
    if(alarmFlag == 1){
        RED_LED = 0;
        putsUart0("Motion Detected\n");
        waitMicrosecond(10);
        RED_LED = 1;
        waitMicrosecond(1000000);
    }
    GPIO_PORTE_ICR_R = MOTION_PORT_MASK;
}

void enableSpinMode()
{
    spinFlag = 1;
}

void spinMode()
{
    int dist;
    if(spinCounter == 4){
        dist = (7.2 * spinChoice);
        setDistance(dist);
        setCW();
        leaveSpin = 1;
        spinFlag = 0;
        spinCounter = 0;
        spinMax = 0;
        spinChoice = 0;
    }

    if(spinFlag == 1){
        putsUart0("Pinging during spin\n");
        // Forcing third ping to be longest
        if(spinCounter == 3){
            i = 400;
        }

        waitMicrosecond(500000);
        dist = 7.2;
        setDistance(dist);
        setCW();
        if(i > spinMax){
            spinMax = i;
            spinChoice = spinCounter;
        }
        spinCounter++;
    }
    return;
}

// This function runs the robot's auto-navigation routine.
// The robot simply traverses a room, periodically stopping to
// measure for distance and passive IR signals. This ensures
// that the robot does not run into walls, and detect motion
void autoNavTimerIsr()
{
    if((autoNavCounter >= 1) && (alarmFlag == 0) && (spinFlag == 0)){
        setForward(1023);
    }

    if(autoNavFlag == 1)
    {
        i = 250;

        // Start Auto Navigation
        autoNavCounter++;

        // Forcing the 50th ping to be "too close" (error correction)
        if(((autoNavCounter % 50) == 0) && (alarmFlag == 0))
        {
            putsUart0("Force Test Spin\n");
            i = 100;
        }

        // Enable spin mode if ping() reveals the robot is
        // too close. Currently set to 200mm
        if((spinFlag == 0) && (alarmFlag == 0)){
            //ping();
            putsUart0("Pinging\n");
            if(i < 200){
                setStop();
                enableSpinMode();
            }
        }

        // Turn every 2 seconds if spinFlag is on
        if((autoNavCounter % 2) == 0)
        {
            spinMode();
        }

        // Enter alarm mode every 35 seconds
        if(((autoNavCounter % 35) == 0) && (spinFlag == 0))
        {
            putsUart0("Entering Alarm Mode\n");
            alarmFlag = 1;
            setStop();
            alarmCounter = autoNavCounter;
        }

        if(((autoNavCounter - alarmCounter) >= 8) && (alarmFlag == 1) && (spinFlag == 0))
        {
            putsUart0("Exiting Alarm Mode\n");
            alarmFlag = 0;
            RED_LED = 0;
            setForward(1023);
        }
        i = 250;
    }

    TIMER3_ICR_R |= TIMER_ICR_TATOCINT;
}

void enableAuto()
{
    autoNavFlag = 1;
    autoNavCounter = 0;
}

void disableAuto()
{
    autoNavFlag = 0;
    autoNavCounter = 0;
}

int getLeaveSpin()
{
    return leaveSpin;
}

void clearLeaveSpin()
{
    leaveSpin = 0;
}

int getAutoFlag()
{
    return autoNavFlag;
}
