// LED Interrupts Library
// David Denny

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL with LCD Interface
// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

// Hardware configuration:

// Left Transistor (PD0) drives low edge interrupt
// Right Transistor (PD2) drives another low edge interrupt
// Using Timers 1A and 2A (narrow)

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <led_interrupts.h>
#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "uart0.h"
#include "ultrasonic_interrupts.h"

// Define LEDs (outputs) and Photo Transistors (inputs)
#define LEFT_LIGHT   (*((volatile uint32_t *)(0x42000000 + (0x400073FC-0x40000000)*32 + 0*4))) // PD0
#define RIGHT_LIGHT  (*((volatile uint32_t *)(0x42000000 + (0x400073FC-0x40000000)*32 + 2*4))) // PD2

// Port D masks
#define LEFT_LIGHT_MASK 1
#define RIGHT_LIGHT_MASK 4

// Ultrasonic Definitions:

// Bitband aliases
#define ECHO_PORT       (*((volatile uint32_t *)(0x42000000 + (0x400073FC-0x40000000)*32 + 3*4))) // PD3

// Port D masks
#define ECHO_PORT_MASK 8

void initInterrupts()
{
    // Enable clocks
    // Using two one-shot timers
    SYSCTL_RCGCTIMER_R |= SYSCTL_RCGCTIMER_R1 | SYSCTL_RCGCTIMER_R2;

    // Interrupt Initialization =========================================================

    // Using GPIO ports D, F
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R3 | SYSCTL_RCGCGPIO_R5;
    _delay_cycles(3);

//    // Configure LED and pushbutton pins
    GPIO_PORTD_DEN_R |= LEFT_LIGHT_MASK | RIGHT_LIGHT_MASK;
//
//    GPIO_PORTF_DIR_R |= RED_LED_MASK | BLUE_LED_MASK;
    GPIO_PORTD_DIR_R &= ~(LEFT_LIGHT_MASK | RIGHT_LIGHT_MASK);

    // Transistors drive pull-up registers
    GPIO_PORTD_PUR_R |= LEFT_LIGHT_MASK | RIGHT_LIGHT_MASK;

    // Configure falling edge interrupts on Photo Transistor inputs
    // (edge mode, single edge, falling edge, clear any interrupts, turn on)
    GPIO_PORTD_IS_R &= ~(LEFT_LIGHT_MASK | RIGHT_LIGHT_MASK);
    GPIO_PORTD_IBE_R &= ~(LEFT_LIGHT_MASK | RIGHT_LIGHT_MASK);
    GPIO_PORTD_IEV_R &= ~(LEFT_LIGHT_MASK | RIGHT_LIGHT_MASK);
    GPIO_PORTD_ICR_R = LEFT_LIGHT_MASK | RIGHT_LIGHT_MASK;
    GPIO_PORTD_IM_R |= LEFT_LIGHT_MASK | RIGHT_LIGHT_MASK;
    NVIC_EN0_R = 1 << (INT_GPIOD-16); // turn on interrupt 19 (Port D)

    // Timer initialization =============================================================

    // Configure Timer 1 for left led
    TIMER1_CTL_R &= ~TIMER_CTL_TAEN;                 // turn-off timer before reconfiguring
    TIMER1_CFG_R = TIMER_CFG_32_BIT_TIMER;           // configure as 32-bit timer (A+B)
    TIMER1_TAMR_R = TIMER_TAMR_TAMR_1_SHOT;          // configure for one-shot mode (count down)
    TIMER1_TAILR_R = 1250000;                        // set load value to 1e6 for 40 Hz interrupt rate
    NVIC_EN0_R = 1 << (INT_TIMER1A-16);              // turn-on interrupt 37 (TIMER1A)

    // Configure Timer 2 for right led
    TIMER2_CTL_R &= ~TIMER_CTL_TAEN;                 // turn-off timer before reconfiguring
    TIMER2_CFG_R = TIMER_CFG_32_BIT_TIMER;           // configure as 32-bit timer (A+B)
    TIMER2_TAMR_R = TIMER_TAMR_TAMR_1_SHOT;          // configure for one-shot mode (count down)
    TIMER2_TAILR_R = 1250000;                        // set load value to 1e6 for 40 Hz interrupt rate
    NVIC_EN0_R = 1 << (INT_TIMER2A-16);              // turn-on interrupt 39 (TIMER2A)
}

void ledIsr() // Debounce
{
    // IM register controls if the interrupt is off/on
    // ICR register controls the clearing of an interrupt

    if(GPIO_PORTD_MIS_R & LEFT_LIGHT_MASK){ // ======== LEFT CAUSED INTERRUPT ==========
        // Left = Red LED
        //toggleRed(); // Toggle LED
        incrementLeft();
        GPIO_PORTD_IM_R &= ~(LEFT_LIGHT_MASK);  // Turn off GPIO interrupts for pin PD0
        TIMER1_CTL_R |= TIMER_CTL_TAEN;         // turn-on timer 1A
        TIMER1_IMR_R = TIMER_IMR_TATOIM;        // force turn-on timer 2A
        GPIO_PORTD_ICR_R = LEFT_LIGHT_MASK;     // Clear interrupt
    }
    else if(GPIO_PORTD_MIS_R & RIGHT_LIGHT_MASK){ // === RIGHT CAUSED INTERRUPT =========
        // Right = Blue LED
        //toggleBlue();                           // Toggle LED
        incrementRight();
        GPIO_PORTD_IM_R &= ~(RIGHT_LIGHT_MASK); // Turn off GPIO interrupts for pin PD2
        TIMER2_CTL_R |= TIMER_CTL_TAEN;         // turn-on timer 2A
        TIMER2_IMR_R = TIMER_IMR_TATOIM;        // force turn-on timer 2A
        GPIO_PORTD_ICR_R = RIGHT_LIGHT_MASK;    // Clear interrupt
    }

    // Clear as a precaution
    GPIO_PORTD_ICR_R = LEFT_LIGHT_MASK | RIGHT_LIGHT_MASK | ECHO_PORT_MASK;
    //GPIO_PORTD_ICR_R = LEFT_LIGHT_MASK | RIGHT_LIGHT_MASK;
}

void timerLeftIsr() // Timer (25ms) for left wheel
{
    GPIO_PORTD_ICR_R = LEFT_LIGHT_MASK;     // Clear interrupt
    GPIO_PORTD_IM_R |= LEFT_LIGHT_MASK;     // Turn on GPIO interrupt
    TIMER1_ICR_R |= TIMER_ICR_TATOCINT;     // Turn off timer
    TIMER1_IMR_R &= ~TIMER_IMR_TATOIM;      // force turn-off timer 2A
}

void timerRightIsr() // Timer (25ms) for right wheel
{
    GPIO_PORTD_ICR_R = RIGHT_LIGHT_MASK;    // Clear interrupt
    GPIO_PORTD_IM_R |= RIGHT_LIGHT_MASK;    // Turn on GPIO interrupt
    TIMER2_ICR_R |= TIMER_ICR_TATOCINT;     // Turn off timer
    TIMER2_IMR_R &= ~TIMER_IMR_TATOIM;      // force turn-off timer 2A
}

void toggleRed()
{
    //RED_LED ^= 1;
    return;
}

void toggleBlue()
{
    //BLUE_LED ^= 1;
    return;
}
