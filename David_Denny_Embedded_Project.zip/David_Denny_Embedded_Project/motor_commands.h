// Motor Command Library
// David Denny

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL with LCD Interface
// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdint.h>

#ifndef MOTOR_COMMANDS_H_
#define MOTOR_COMMANDS_H_

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

int checkSpeed();
void determineStop();
void leftForwardTooFast();
void rightForwardTooFast();
void equalizeWheels();
void incrementLeft();
void incrementRight();

void clearCounters();
void setDistance();

void setForward();
void setReverse();
void setCCW();
void setCW();
void setStop();


#endif
