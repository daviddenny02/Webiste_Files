// Motor PWM Library
// David Denny

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL with LCD Interface
// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

// Hardware configuration:

// Motor Input 1 (PC5) drives Input 1 on Motor DRV, M0PWM7
// Motor Input 2 (PC4) drives Input 2 on Motor DRV, M0PWM6
// Motor Input 3 (PA6) drives Input 3 on Motor DRV, M1PWM2
// Motor Input 4 (PA7) drives Input 4 on Motor DRV, M1PWM3
// Sleep (PC6) drives sleep input on Motor DRV

// DRV Output 1 drives the positive right motor (+)
// DRV Output 2 drives the negative right motor (-)
// DRV Output 3 drives the positive left motor (+)
// DRV Output 4 drives the negative left motor (-)

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <motor_pwm.h>
#include <stdint.h>
#include "tm4c123gh6pm.h"

#define MOTOR_INPUT_ONE_MASK 32
#define MOTOR_INPUT_TWO_MASK 16
#define MOTOR_INPUT_THREE_MASK 64
#define MOTOR_INPUT_FOUR_MASK 128

// Initialize Motors
void initMotors()
{
    // Enable clocks
    // Using PWM modules 0, 1
    SYSCTL_RCGCPWM_R |= SYSCTL_RCGCPWM_R0 | SYSCTL_RCGCPWM_R1;
    // Using GPIO ports A, C
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R0 | SYSCTL_RCGCGPIO_R2;
    _delay_cycles(3);

    // Configure four motor Inputs
    GPIO_PORTC_DEN_R |= MOTOR_INPUT_ONE_MASK | MOTOR_INPUT_TWO_MASK;
    GPIO_PORTA_DEN_R |= MOTOR_INPUT_THREE_MASK | MOTOR_INPUT_FOUR_MASK;

    GPIO_PORTC_AFSEL_R |= MOTOR_INPUT_ONE_MASK | MOTOR_INPUT_TWO_MASK;
    GPIO_PORTA_AFSEL_R |= MOTOR_INPUT_THREE_MASK | MOTOR_INPUT_FOUR_MASK;

    GPIO_PORTC_PCTL_R &= ~(GPIO_PCTL_PC4_M | GPIO_PCTL_PC5_M);
    GPIO_PORTA_PCTL_R &= ~(GPIO_PCTL_PA6_M | GPIO_PCTL_PA7_M);

    GPIO_PORTC_PCTL_R |= GPIO_PCTL_PC4_M0PWM6 | GPIO_PCTL_PC5_M0PWM7;
    GPIO_PORTA_PCTL_R |= GPIO_PCTL_PA6_M1PWM2 | GPIO_PCTL_PA7_M1PWM3;

    // Configure Modules to drive motors
    // Motor Input 1 = PC5 = M0PWM7 = M0PWM3b
    // Motor Input 2 = PC4 = M0PWM6 = M0PWM3a
    // Motor Input 3 = PA6 = M1PWM2 = M1PWM1a
    // Motor Input 4 = PA7 = M1PWM3 = M1PWM1b
    // reset PWM0 and PWM1 modules
    SYSCTL_SRPWM_R = SYSCTL_SRPWM_R0 | SYSCTL_SRPWM_R1;
    SYSCTL_SRPWM_R = 0; // leave reset state
    PWM0_3_CTL_R = 0;   // turn-off PWM0 generator 3 (drives outs 6 and 7)
    PWM1_1_CTL_R = 0;   // turn-off PWM1 generator 1 (drives outs 2 and 3)

    // Output 1 on PWM0 generator 3b, cmp b
    PWM0_3_GENB_R = PWM_3_GENB_ACTCMPBD_ONE | PWM_3_GENB_ACTLOAD_ZERO;
    // Output 2 on PWM0 generator 3a, cmp a
    PWM0_3_GENA_R = PWM_3_GENA_ACTCMPAD_ONE | PWM_3_GENA_ACTLOAD_ZERO;
    // Output 3 on PWM1 generator 1a, cmp a
    PWM1_1_GENA_R = PWM_1_GENA_ACTCMPAD_ONE | PWM_1_GENA_ACTLOAD_ZERO;
    // Output 4 on PWM1 generator 1b, cmp b
    PWM1_1_GENB_R = PWM_1_GENB_ACTCMPBD_ONE | PWM_1_GENB_ACTLOAD_ZERO;

    PWM0_3_LOAD_R = 1024; // set frequency to 40 MHz sys clock / 2 / 1024 = 19.53125 kHz
    PWM1_1_LOAD_R = 1024;

    // Turn off all PWM registers
    PWM0_3_CMPB_R = 0; // Motor Input 1
    PWM0_3_CMPA_R = 0; // Motor Input 2
    PWM1_1_CMPA_R = 0; // Motor Input 3
    PWM1_1_CMPB_R = 0; // Motor Input 4

    PWM0_3_CTL_R = PWM_3_CTL_ENABLE; // turn on PWM0 generator 3
    PWM1_1_CTL_R = PWM_1_CTL_ENABLE; // turn on PWM1 generator 1

    // enable outputs
    PWM0_ENABLE_R = PWM_ENABLE_PWM6EN | PWM_ENABLE_PWM7EN;
    PWM1_ENABLE_R = PWM_ENABLE_PWM2EN | PWM_ENABLE_PWM3EN;
}
