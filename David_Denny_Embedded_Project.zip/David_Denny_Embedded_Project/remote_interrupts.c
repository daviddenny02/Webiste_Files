// Remote Interrupts Library
// David Denny

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL with LCD Interface
// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

// Hardware configuration:

// IR detector (PC7) drives low edge interrupts
// Using Timer 0A (narrow)

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <remote_interrupts.h>
#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "uart0.h"
#include "wait.h"
#include "motor_commands.h"
#include "ultrasonic_interrupts.h"

// Bitband aliases
#define REMOTE_PORT   (*((volatile uint32_t *)(0x42000000 + (0x400063FC-0x40000000)*32 + 7*4))) // Port C
#define GREEN_LED     (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 3*4))) // PF3  // To remove

// Port C masks
#define REMOTE_PORT_MASK 128

// Port F masks
#define GREEN_LED_MASK 8  // To remove

// Global Variables
int32_t currentTime = 0;
int32_t currentBit = 0;
int8_t primingRead = 0;
int8_t currentlyReading = 0;
static int8_t remoteCommand[32];

// Below are all the commands issued from the used remote, including
// their respective data streams from the remote. This data is picked
// up and acted upon by the IR Sensor and Microcontroller:

//  Button Commands:

//  00100000 11011111 00100010 11011101 STOP == 68
//  00100000 11011111 00000010 11111101 FORWARD == 64
//  00100000 11011111 01100000 10011111 CLOCKWISE == 6
//  00100000 11011111 10000010 01111101 REVERSE == 65
//  00100000 11011111 11100000 00011111 COUNTER-CLOCKWISE == 7

// Extra Button Commands, may use to enter/leave patrol mode:

//  00100000 11011111 10001000 01110111 ONE == 17 == Enter Sentry Mode
//  00100000 11011111 01001000 10110111 TWO == 18 == Exit Sentry Mode
//  00100000 11011111 11001000 00110111 THREE == 19 == Ping

void initRemoteInterrupts()
{
    // GPIO Interrupt Initialization ====================================================

    // Using Narrow Timer 0A
    SYSCTL_RCGCTIMER_R |= SYSCTL_RCGCTIMER_R0;

    // Using GPIO ports C, F
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R2 | SYSCTL_RCGCGPIO_R5; // To remove R5
    _delay_cycles(3);

    // Configure IR output pins
    GPIO_PORTC_DEN_R |= REMOTE_PORT_MASK;
    GPIO_PORTF_DEN_R |= GREEN_LED_MASK; // To remove

    GPIO_PORTC_DIR_R &= ~(REMOTE_PORT_MASK);
    GPIO_PORTF_DIR_R |= GREEN_LED_MASK; // To remove

    // Transistors drive pull-up registers
    GPIO_PORTC_PUR_R |= REMOTE_PORT_MASK;

    // Configure falling edge interrupts on IR detector inputs
    // (edge mode, single edge, falling edge, clear any interrupts, turn on)
    GPIO_PORTC_IS_R &= ~(REMOTE_PORT_MASK);
    GPIO_PORTC_IBE_R &= ~(REMOTE_PORT_MASK);
    GPIO_PORTC_IEV_R &= ~(REMOTE_PORT_MASK);
    GPIO_PORTC_ICR_R |= REMOTE_PORT_MASK;
    GPIO_PORTC_IM_R |= REMOTE_PORT_MASK;
    NVIC_EN0_R = 1 << (INT_GPIOC-16); // turn on interrupt 18 (Port C)

    // Configure Timer 0 as the time base
    TIMER0_CTL_R &= ~TIMER_CTL_TAEN;                 // turn-off timer before reconfiguring
    TIMER0_CFG_R = TIMER_CFG_32_BIT_TIMER;           // configure as 32-bit timer (A+B)
    TIMER0_TAMR_R = TIMER_TAMR_TAMR_1_SHOT;          // configure for periodic mode (count down)
    TIMER0_TAILR_R = 4000000;                        // set load value to 4e6 for 10 Hz interrupt rate
    TIMER0_IMR_R = TIMER_IMR_TATOIM;                 // turn-on interrupts
    NVIC_EN0_R = 1 << (INT_TIMER0A-16);              // turn-on interrupt 35 (TIMER0A)
    return;
}

void remoteIsr()
{
    //putsUart0("Entered here\n");
    if(currentBit >= 32){
        goto stopGPIO;
    }

    GREEN_LED = 1;                                  // Indicate Signal
    //putsUart0("FLAG5\n");
    TIMER0_CTL_R |= TIMER_CTL_TAEN;                 // Turn-on timer
    currentTime = 4000000 - TIMER0_TAV_R;           // Find time

    // Start reading
    if(currentlyReading == 1){
        // 0 was read
        if((currentTime >= 33750) && (currentTime <= 56250)){
            remoteCommand[currentBit] = 0;
            currentBit++;
            putcUart0('0');
        }
        // 1 was read
        else if((currentTime >= 78750) && (currentTime <= 101250)){
            remoteCommand[currentBit] = 1;
            // This occurs in the event the first leading 0 was lost
            if((currentBit == 1) && (remoteCommand[1] == 1)){
                remoteCommand[0] = 0;
                remoteCommand[1] = 0;
                remoteCommand[2] = 1;
                currentBit++;
                putcUart0('0');
            }
            currentBit++;
            putcUart0('1');
        }
        else{ // Stop reading if in no-man's land
            currentlyReading = 0;
        }
    }

stopGPIO:

    if(currentBit >= 32){
        runRemoteCommand();
        clearRemoteCommand();
        GPIO_PORTC_ICR_R = REMOTE_PORT_MASK;           // clear interrupts
    }

    // Skip these statements if currentlyReading
    if((primingRead == 1) && (currentlyReading == 0)){
        if((currentTime >= 520000) || (currentTime <= 560000)){
            // Pre-amble detected, currentlyReading
            currentlyReading = 1;
            primingRead = 0;
        }
        else{ // Reset Flags as a precaution
            primingRead = 0;
            currentlyReading = 0;
        }
    } // Start the primary read
    else if((primingRead == 0) && (currentlyReading == 0)){
        primingRead = 1;
    }

    if(GREEN_LED == 0){
        clearRemoteCommand();
    }

    TIMER0_TAV_R = 4000000;                        // reset timer
    GPIO_PORTC_ICR_R = REMOTE_PORT_MASK;           // clear interrupts
}

// If timer reaches 0 (~0.1sec) then force the read to end
void remoteTimerIsr()
{
    // Clear everything and run the command
    currentlyReading = 0;
    currentBit = 0;
    clearRemoteCommand();
    setStop();
    GREEN_LED = 0;
    TIMER0_ICR_R |= TIMER_ICR_TATOCINT;
}

// For clarity's sake
void clearRemoteCommand()
{
    int i;
    for(i = 0; i < 32; i++){
        remoteCommand[i] = 0;
    }
    return;
}

// This function checks for a valid command and runs it
void runRemoteCommand()
{
    putcUart0('\n');
    // Check for valid bits
    int i;
    for(i = 0; i < 8; i++){
        if((remoteCommand[i] != !remoteCommand[i + 8]) || (remoteCommand[i + 16] != !remoteCommand[i + 24])){
            return;
        }
    }

    // Find value of the command to run
    int commandValue = 0;
    int exp = 1;
    for(i = 0; i < 8; i++){
        commandValue += (exp * remoteCommand[i + 16]);
        exp *= 2;
    }

    // Run the command
    if(commandValue == 68){putsUart0("Stopping...\n"); setStop();}
    if(commandValue == 64){putsUart0("Moving Forward\n"); setForward(1023);}
    if(commandValue == 6){putsUart0("Rotating Clockwise\n"); setCW();}
    if(commandValue == 65){putsUart0("Moving Backwards\n"); setReverse(1023);}
    if(commandValue == 7){putsUart0("Rotating Counter-Clockwise\n"); setCCW();}

    if(commandValue == 17){putsUart0("Enabling Auto Navigation\n"); enableAuto();}
    if(commandValue == 18){putsUart0("Disabling Auto Navigation\n"); disableAuto();}
    if(commandValue == 19){putsUart0("3 Detected\n");}

    return;
}