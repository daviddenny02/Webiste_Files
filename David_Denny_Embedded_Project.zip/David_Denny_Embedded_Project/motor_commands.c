// Motor Commands Library
// David Denny

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL with LCD Interface
// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <remote_interrupts.h>
#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "uart0.h"
#include "wait.h"
#include "ultrasonic_interrupts.h"

int clearFlag = 0;

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

// Global Variables:
int32_t leftCounter = 0;
int32_t rightCounter = 0;
int32_t distance = -1;
int32_t leftCorrector = 0;
int32_t rightCorrector = 0;

int checkSpeed(int speed)
{
    if(speed <= 0){
        return 0;
    } // Do nothing if 0 is entered
    else if(speed > 10000){
        return 0;
    } // Do nothing if >10000 is entered
    return speed;
}

//    PWM0_3_CMPB_R = Motor Input 1 RIGHT FORWARD
//    PWM0_3_CMPA_R = Motor Input 2 RIGHT REVERSE
//    PWM1_1_CMPA_R = Motor Input 3 LEFT REVERSE
//    PWM1_1_CMPB_R = Motor Input 4 LEFT FORWARD

void leftForwardTooFast()
{
    if(PWM1_1_CMPB_R >= leftCorrector){ // Decrease Left Forward Speed
        PWM1_1_CMPB_R = 0.95 * (PWM1_1_CMPB_R - leftCorrector);
    }
    return;
}

void rightForwardTooFast()
{
    if(PWM0_3_CMPB_R >= rightCorrector){ // Decrease Right Forward Speed
        PWM0_3_CMPB_R = (PWM0_3_CMPB_R - rightCorrector);
    }
    return;
}

void equalizeWheels()
{
    // Make move straight
    if((leftCounter - rightCounter) == 1){ // Left motor is too fast
        leftCorrector = 2;
        if((abs(PWM1_1_CMPB_R - PWM0_3_CMPB_R)) <= 4){
            leftForwardTooFast();
        }
    }
    if((leftCounter - rightCounter) == 2){ // Left motor is too fast
        leftCorrector = 4;
        if((abs(PWM1_1_CMPB_R - PWM0_3_CMPB_R)) <= 8){
            leftForwardTooFast();
        }
    }
    if((leftCounter - rightCounter) >= 3){ // Left motor is too fast
        leftCorrector = 8;
        if((abs(PWM1_1_CMPB_R - PWM0_3_CMPB_R)) <= 16){
            leftForwardTooFast();
        }
    }
    if(leftCounter == rightCounter){ // Correct Speed
        leftCorrector = 0;
        rightCorrector = 0;
    }
    if((rightCounter - leftCounter) == 1){ // Right motor is too fast
        rightCorrector = 2;
        if((abs(PWM0_3_CMPB_R - PWM1_1_CMPB_R)) <= 4){
            rightForwardTooFast();
        }
    }
    if((rightCounter - leftCounter) == 2){ // Right motor is too fast
        rightCorrector = 4;
        if((abs(PWM0_3_CMPB_R - PWM1_1_CMPB_R)) <= 8){
            rightForwardTooFast();
        }
    }
    if((rightCounter - leftCounter) >= 3){ // Right motor is too fast
        rightCorrector = 8;
        if((abs(PWM0_3_CMPB_R - PWM1_1_CMPB_R)) <= 16){
            rightForwardTooFast();
        }
    }
    return;
}

void clearCounters()
{
    leftCounter = 0;
    rightCounter = 0;
}

void setDistance(int distanceTemp)
{
    distance = distanceTemp;
}

void setForward(int speed){
    clearCounters();
    PWM0_3_CMPB_R = speed; 			// Motor Input 1 RIGHT FORWARD
    PWM0_3_CMPA_R = 0; 				// Motor Input 2 RIGHT REVERSE
    PWM1_1_CMPA_R = 0; 				// Motor Input 3 LEFT REVERSE
    PWM1_1_CMPB_R = speed * 0.99; 	// Motor Input 4 LEFT FORWARD
}

void setReverse(int speed){
    clearCounters();
    PWM0_3_CMPB_R = 0; 				// Motor Input 1
    PWM0_3_CMPA_R = speed; 			// Motor Input 2
    PWM1_1_CMPA_R = speed; 			// Motor Input 3
    PWM1_1_CMPB_R = 0; 				// Motor Input 4
}

void setCCW(){
    clearCounters();
    PWM0_3_CMPB_R = 1023; 			// Motor Input 1
    PWM0_3_CMPA_R = 0; 				// Motor Input 2
    PWM1_1_CMPA_R = 1023; 			// Motor Input 3
    PWM1_1_CMPB_R = 0; 				// Motor Input 4
}

void setCW(){
    clearCounters();
    PWM0_3_CMPB_R = 0; 				// Motor Input 1
    PWM0_3_CMPA_R = 1023; 			// Motor Input 2
    PWM1_1_CMPA_R = 0; 				// Motor Input 3
    PWM1_1_CMPB_R = 1023; 			// Motor Input 4
}

void setStop(){
    PWM0_3_CMPB_R = 1023; 			// Motor Input 1
    PWM0_3_CMPA_R = 1023; 			// Motor Input 2
    PWM1_1_CMPA_R = 1023; 			// Motor Input 3
    PWM1_1_CMPB_R = 1023; 			// Motor Input 4
    waitMicrosecond(10000);
    clearCounters();
}

void determineStop()
{
    if(((leftCounter + rightCounter)/2) == distance){
        putsUart0("Stopping...\n");
        setStop();
        distance = -1;
        leftCounter = 0;
        rightCounter = 0;
        if(getLeaveSpin() == 1){
            putsUart0("Leaving spin, forward\n");
            clearLeaveSpin();
            waitMicrosecond(500000);
            setForward(1023);
        }
    }
    return;
}

void incrementLeft()
{
    leftCounter++;
    determineStop();
    equalizeWheels();
    return;
}

void incrementRight()
{
    rightCounter++;
    determineStop();
    equalizeWheels();
    return;
}
