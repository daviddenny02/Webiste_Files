// =============================
// David Denny, 1001915603
// Operating Systems, Program 1
// Dr. Bakker
// Due 2/21/2024
// =============================

#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>

#define WHITESPACE " \t\n"      // We want to split our command line up into tokens
                                // so we need to define what delimits our tokens.
                                // In this case  white space
                                // will separate the tokens on our command line

#define MAX_COMMAND_SIZE 255    // The maximum command-line size

#define MAX_NUM_ARGUMENTS 32

// =========================================================================

// Function to remove leading whitespace of a given command
int variableWhitespace(char* command_string){
  
  int i = 0;
  int j = 0;
  int k = 0;
  
  char tempString[MAX_COMMAND_SIZE];
  while((command_string[i] == ' ') || (command_string[i] == '\t')){
    i++;
  }

  // Continue/discard command if only whitespace characters are entered.
  int commandLength = strlen(command_string);
  if(i == commandLength - 1){
    return -1;
  }

  // Copy the contents of the command into a tempString
  for(j = i; command_string[j] != '\0'; j++){
    tempString[k] = command_string[j];
    k++;
  }

  // Copy the string (now without leading whitespace!)
  strcpy(command_string, tempString);
  return 0;
}

// =========================================================================

// Function to concatenate command to be checked/run, and returns runCommand
void concatenatePath(char* Pathfinder, char* token){
    int i;
    int j = strlen(Pathfinder);
 
    // As long as the end of token has not been reached, add/concatenate it
    // onto the end of the path passed in
    for (i = 0; token[i] != '\0'; i++){
        Pathfinder[i + j] = token[i];
    }
    // Set last char in string to \0 for signal the end of the string
    Pathfinder[(i + j)] = '\0';

    return;
}

// =========================================================================

// Execution function -- This function finds file path if it exists, and
// executes. This file implements cd and exit seperatley, and returns a -1
// if an error occurs.
int executeThis(char **token, int token_count){
  // IMPLEMENTED COMMANDS: 'exit' and 'cd'
  // Test if the user has input exit to end the program.
  if(((strcmp(token[0], "exit")) == 0) || ((strcmp(token[0], "Exit")) == 0)){
      if(token[1] != NULL){
        return -1;
      }
      else{
        exit(0); // Exit gracefully
      }
    }

    // Test if the user has input cd to change directories
    if((strcmp(token[0], "cd")) == 0){
      if(token[1] == NULL){ // Incorrect usage of cd
        return -1;
      }
      else{
        if(chdir(token[1]) == -1){ // Correct usage of cd, chdir returns -1 if error
          return -1;
        }
        else{
          return 0;
        }
      }
    }

    char binPathfinder[MAX_COMMAND_SIZE] = "/bin/";
    char usrbinPathfinder[MAX_COMMAND_SIZE] = "/usr/bin/";
    char usrlocalbinPathfinder[MAX_COMMAND_SIZE] = "/usr/local/bin/";
    char otherPathfinder[MAX_COMMAND_SIZE] = "./";
    char runCommand[MAX_COMMAND_SIZE];

    // Concatenate to /bin/x
    concatenatePath(binPathfinder, token[0]);
    if(access(binPathfinder, X_OK) == -1){
      // Command not found in /bin/x
      // Concatenate to /usr/bin/x
      concatenatePath(usrbinPathfinder, token[0]);
      
      if(access(usrbinPathfinder, X_OK) == -1){
        // Command not found in /usr/bin/x
        // Concatenate to /usr/local/bin/x
        concatenatePath(usrlocalbinPathfinder, token[0]);
        
        if(access(usrlocalbinPathfinder, X_OK) == -1){
          // Command not found in /usr/local/bin/x
          // Concatenate to ./x
          concatenatePath(otherPathfinder, token[0]);
          
          if(access(otherPathfinder, X_OK) == -1){
            // Command not found in ./x, command DNE
            return -1;
          }
          else{
            // Command found in ./x
            strcpy(runCommand, otherPathfinder);
          }
        }
        else{
          // Command found in /usr/local/bin/x
          strcpy(runCommand, usrlocalbinPathfinder);
        }
      }
      else{
        // Command found in /usr/bin/x
        strcpy(runCommand, usrbinPathfinder);
      }
    }
    else{
      // Command found in /bin/x
      strcpy(runCommand, binPathfinder);
    }

    // Execute the file!
    // Set the arguments to their own array
    // To use execv, split the token string into the executable, then an array of arguments
    pid_t child_pid = fork();
    int status;

    if( child_pid == 0 ){
      if(execv(runCommand, token) == -1){ // Returns -1 if an error occurs (incorrect arguments)
        return -1;
      }
      return 0;
    }

    waitpid( child_pid, &status, 0 );

  return 0;
}

  // ================================= MAIN ==================================

int main(int argc, char *argv[]){

  if(argc > 2){ // Incorrect usage of batch mode
    char error_message[30] = "An error has occurred\n";
    write(STDERR_FILENO, error_message, strlen(error_message)); 
    exit(1);
  }

  // ========================== Interactive Mode =============================

  if(argc == 1){ // Interactive mode

    char * command_string = (char*) malloc( MAX_COMMAND_SIZE );

    while(1)
    {
      // Print out the msh prompt
      printf ("msh> ");

      // Read the command from the command line.  The
      // maximum command that will be read is MAX_COMMAND_SIZE
      // This while command will wait here until the user
      // inputs something.
      while(!fgets(command_string, MAX_COMMAND_SIZE, stdin));

      // Test if there are any leading whitespaces and remove them
      // Trailing whitespace can be left without impacting anything
      if((command_string[0] == ' ') || (command_string[0] == '\t')){
        if(variableWhitespace(command_string) == -1){
          continue;
        }
      }

      // Error for empty command -- User only pressed enter
      if((strcmp(command_string, "\n") == 0) || (strcmp(command_string, "") == 0)){
        continue;
      }

      /* Parse input */
      char *token[MAX_NUM_ARGUMENTS];
      int token_count = 0;                                 
                                                            
      // Pointer to point to the token
      // parsed by strsep
      char *argument_pointer;                                                                                        
      char *working_string  = strdup( command_string );                

      // we are going to move the working_string pointer so
      // keep track of its original value so we can deallocate
      // the correct amount at the end
      char *head_ptr = working_string;
      
      // Tokenize the input with whitespace used as the delimiter
      while ( ( (argument_pointer = strsep(&working_string, WHITESPACE ) ) != NULL) &&
                (token_count<MAX_NUM_ARGUMENTS))
      {
        token[token_count] = strndup( argument_pointer, MAX_COMMAND_SIZE );
        if( strlen( token[token_count] ) == 0 )
        {
          token[token_count] = NULL;
        }
          token_count++;
      }

      // =========================== REDIRECTION =============================
      int redirectionFlag = 0;
      int token_index = 0;

      for( token_index = 0; token_index < token_count; token_index ++ ){
        // Prevent the future strcmp from seg faulting
        if(token[token_index] == NULL){
          continue;
        }

        // Check for ">" to redirect
        if( strcmp( token[token_index], ">" ) == 0 ){
          redirectionFlag = 1;
          
          if((token[token_index] == NULL)|| (token_index == 0)){ // Error if no redirection target given
            char error_message[30] = "An error has occurred\n";
            write(STDERR_FILENO, error_message, strlen(error_message));
            continue;
          }

          if(token[token_index + 2] != NULL){ // Error if multiple redirects given
            char error_message[30] = "An error has occurred\n";
            write(STDERR_FILENO, error_message, strlen(error_message));
            break;
          }
         
          // Change the output to the file
          int fd = open(token[token_index + 1], O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);

          if(fd < 0){ // Can't open output file
            char error_message[30] = "An error has occurred\n";
            write(STDERR_FILENO, error_message, strlen(error_message));
            continue;
          }
          
          // Save the standard output to restore after the redirect command executes
          int savedStdout;
          savedStdout = dup(1);
          dup2(fd, 1);
          close(fd);
          token[token_index] = NULL;

          // Execute the command with redirection
          // Regardless if it is successful, restore the standard output before continuing
          if(executeThis(token, token_count) == -1){
            char error_message[30] = "An error has occurred\n";
            write(STDERR_FILENO, error_message, strlen(error_message));
            dup2(savedStdout, 1);
            close(savedStdout);
            continue;
          }
          else{
            dup2(savedStdout, 1);
            close(savedStdout);
            continue;
          }
        }
      }

      // Don't execute multiple times if redirection is called
      if(redirectionFlag == 1){
        continue;
      }
      // ====================== END REDIRECTION ===================================

      // Execute the command (without redirection), error out if unsucessful
      if(executeThis(token, token_count) == -1){
        char error_message[30] = "An error has occurred\n";
        write(STDERR_FILENO, error_message, strlen(error_message)); 
        continue;
      }
      else{ // Continue after a successful command
        continue;
      }
      // Free head pointer
      free(head_ptr);
    }
  }
  
  // ============================= Batch Mode ================================

  // NOTE:  Much of this code is similar to interactive mode, minimal notes
  //        will be given
  
  if(argc == 2){ // Batch mode

    FILE *inputFile = fopen(argv[1], "r");
    char * command_string = (char*) malloc( MAX_COMMAND_SIZE );

    if(inputFile == NULL){
      char error_message[30] = "An error has occurred\n";
      write(STDERR_FILENO, error_message, strlen(error_message)); 
      exit(1);
    }

    while(1)
    {
      // In batch mode, we get input from the given file
      fgets(command_string, MAX_COMMAND_SIZE, inputFile);
      
      // Stop recieving commands when EOF is reached
      if(feof(inputFile)){
        exit(0);
      }

      if((command_string[0] == ' ') || (command_string[0] == '\t')){
        if(variableWhitespace(command_string) == -1){
          continue;
        }
      }

      if(strcmp(command_string, "\n") == 0){
        continue;
      }
      
      char *token[MAX_NUM_ARGUMENTS];
      int token_count = 0;                                 
      char *argument_pointer;                                                                                           
      char *working_string  = strdup( command_string );                
      char *head_ptr = working_string;
      
      while ( ( (argument_pointer = strsep(&working_string, WHITESPACE ) ) != NULL) &&
                (token_count<MAX_NUM_ARGUMENTS))
      {
        token[token_count] = strndup( argument_pointer, MAX_COMMAND_SIZE );
        if( strlen( token[token_count] ) == 0 )
        {
          token[token_count] = NULL;
        }
          token_count++;
      }

      // =========================== REDIRECTION =============================

      int redirectionFlag = 0;
      int token_index = 0;

      for( token_index = 0; token_index < token_count; token_index ++ ){
        if(token[token_index] == NULL){
          continue;
        }

        if( strcmp( token[token_index], ">" ) == 0 ){
          redirectionFlag = 1;

          if((token[token_index] == NULL)|| (token_index == 0)){ // Error if no redirection target given
            char error_message[30] = "An error has occurred\n";
            write(STDERR_FILENO, error_message, strlen(error_message));
            continue;
          }

          if(token[token_index + 2] != NULL){ // Error if multiple redirects given
            char error_message[30] = "An error has occurred\n";
            write(STDERR_FILENO, error_message, strlen(error_message));
            break;
          }
         
          int fd = open(token[token_index + 1], O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);

          if(fd < 0){ // Can't open output file
            char error_message[30] = "An error has occurred\n";
            write(STDERR_FILENO, error_message, strlen(error_message));
            continue;
          }

          int savedStdout;
          savedStdout = dup(1);
          dup2(fd, 1);
          close(fd);
          token[token_index] = NULL;

          if(executeThis(token, token_count) == -1){
            char error_message[30] = "An error has occurred\n";
            write(STDERR_FILENO, error_message, strlen(error_message));
            dup2(savedStdout, 1);
            close(savedStdout);
            continue;
          }
          else{
            dup2(savedStdout, 1);
            close(savedStdout);
            continue;
          }
        }
      }

      if(redirectionFlag == 1){
        continue;
      }

      // ====================== END REDIRECTION ===================================

      if(executeThis(token, token_count) == -1){
        char error_message[30] = "An error has occurred\n";
        write(STDERR_FILENO, error_message, strlen(error_message)); 
        continue;
      }
      else{
        continue;
      }
      free( head_ptr );
    }
  }
  // ================================= END ===================================
  
  return 0;
}